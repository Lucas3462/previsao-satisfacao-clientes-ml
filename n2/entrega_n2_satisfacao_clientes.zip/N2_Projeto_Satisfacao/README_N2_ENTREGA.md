# Complemento de entrega N2 - Projeto de satisfação de clientes

Este pacote contém os artefatos de N2 preparados para serem adicionados ao repositório público existente:

https://github.com/Lucas3462/previsao-satisfacao-clientes-ml

**Importante:** o repositório já possui uma pasta `n2` com material anterior. Para não apagar ou substituir esse conteúdo sem revisão, esta entrega foi organizada em `n2_entrega/`. Copie/mescle os arquivos deste pacote para a raiz do repositório, mantendo as pastas de N1 e a pasta `n2` já existente. Não substitua a pasta `n2` antiga por esta pasta.

## Estrutura

- `data/raw/dataset_satisfacao_atendimento.csv`: base usada no experimento.
- `data/dataset_description.md`: origem, descrição e regra do alvo.
- `run_n2.py`: executor principal do treinamento e avaliação.
- `n2_entrega/src/modeling.py`: preparação, pipelines, busca de hiperparâmetros e avaliação.
- `n2_entrega/notebooks/03_modelagem_e_avaliacao.ipynb`: notebook de desenvolvimento e análise.
- `n2_entrega/results/metrics/`: auditoria, comparação de modelos, matriz de confusão, métricas e resumo da execução.
- `n2_entrega/results/figures/`: gráficos gerados pela execução.
- `n2_entrega/results/models/modelo_satisfacao.joblib`: pipeline final serializado.
- `n2_entrega/app_streamlit.py`: interface demonstrativa.
- `n2_entrega/predict.py`: exemplo de previsão via terminal.
- `docs/relatorio_projeto_n2.docx` e `.pdf`: relatório completo.
- `docs/roteiro_video_n2.docx` e `.md`: roteiro de até cinco minutos.

## Como executar na raiz do repositório

```bash
python -m pip install -r requirements.txt
python run_n2.py
```

Para abrir a interface demonstrativa:

```bash
streamlit run n2_entrega/app_streamlit.py
```

Para testar via terminal:

```bash
python n2_entrega/predict.py --faixa-etaria 26-40 --canal WhatsApp --tempo-espera 5 --resolvido Sim --novo-contato Nao --cordial Sim --facilidade 4
```

Para rodar os testes:

```bash
python -m pytest -q
```

Para abrir o notebook, use Jupyter a partir da raiz e abra `n2_entrega/notebooks/03_modelagem_e_avaliacao.ipynb`.

## Resultado de referência

A execução com `random_state=42` produziu 207 registros, com 165 no treino e 42 no teste. O Random Forest obteve a maior média de F1-macro na validação cruzada do treino (0,7538) e foi selecionado. As métricas abaixo são da avaliação independente, antes do reajuste do pipeline. Depois da avaliação, o modelo demonstrativo foi reajustado com as 207 respostas. No teste, o resultado do modelo selecionado foi: acurácia 0,7619; acurácia balanceada 0,7677; F1 da classe Satisfeito 0,8333; F1-macro 0,7083; ROC-AUC 0,9192. A regressão logística teve resultado pontual superior nesse conjunto de teste, fato discutido no relatório.

## Pendências antes da submissão

1. Os integrantes devem revisar o texto, confirmar os números e validar que a documentação representa corretamente a coleta.
2. Executar o código no ambiente que será usado na apresentação e conferir se os arquivos de resultado foram atualizados.
3. Gravar e publicar o vídeo em modo público no YouTube, com no máximo cinco minutos.
4. Inserir a URL pública do vídeo na seção 6 do relatório e no README antes da entrega.
5. Confirmar a composição do grupo, os RAs e preencher os e-mails institucionais dos três alunos. O README público confirma nomes e RAs, mas não publica os e-mails dos alunos; por isso, o relatório contém campos para completar. O e-mail do docente consta no repositório.

Os arquivos e resultados são uma versão de apoio técnico para revisão dos integrantes; a equipe deve validar o conteúdo e assumir a autoria acadêmica da entrega final.
