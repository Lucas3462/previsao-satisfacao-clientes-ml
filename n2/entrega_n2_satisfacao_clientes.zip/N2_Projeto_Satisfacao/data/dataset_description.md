# Descrição do dataset - N2

- **Arquivo:** `dataset_satisfacao_atendimento.csv`
- **Origem:** questionário com coleta própria do grupo, conforme documentação do N1.
- **Dimensão:** 207 respostas e 11 colunas.
- **Tratamento:** arquivo bruto mantido sem alteração; alvo derivado em memória no código.
- **Privacidade:** o material fornecido não contém nomes ou identificadores pessoais diretos. `ID_Resposta` é um identificador técnico e não entra como feature.

| Coluna | Papel na N2 | Descrição |
|---|---|---|
| `ID_Resposta` | Excluída | Identificador técnico da resposta. |
| `Faixa_etaria` | Feature categórica | Faixa etária informada. |
| `Canal_de_atendimento` | Feature categórica | Canal utilizado no atendimento. |
| `Tempo_de_espera_minutos` | Feature numérica | Tempo de espera em minutos. |
| `Problema_foi_resolvido` | Feature categórica | Indica se o problema foi resolvido. |
| `Precisou_contato_novamente` | Feature categórica | Indica necessidade de novo contato. |
| `Atendimento_foi_cordial` | Feature categórica | Avaliação da cordialidade. |
| `Facilidade_para_resolver_1_a_5` | Feature numérica ordinal | Avaliação da facilidade para resolver o problema. |
| `Nota_para_o_atendimento_1_a_5` | Origem do alvo; excluída | Nota de 1 a 5 usada para derivar a classe. |
| `Voltaria_a_comprar` | Excluída | Intenção de nova compra, que pode ser consequência da experiência. |
| `Satisfacao` | Auditoria; excluída | Rótulo original fornecido no CSV, inconsistente com a regra aplicada. |

## Regra de classificação

- Nota 1, 2 ou 3: classe 0 (`Nao-Satisfeito`).
- Nota 4 ou 5: classe 1 (`Satisfeito`).

Na auditoria da N2 foram confirmadas 31 divergências entre `Satisfacao` e a classe derivada (28 notas 4 com rótulo original `Nao-Satisfeito`, 2 notas 5 com rótulo original `Nao-Satisfeito` e 1 nota 3 com rótulo original `Satisfeito`). A base também apresentou zero valores ausentes, zero linhas duplicadas e zero IDs duplicados.

## Uso responsável

A amostra é pequena, pode conter viés de seleção e não representa necessariamente todos os clientes. Os resultados são experimentais; não devem ser utilizados como decisões automáticas nem substituir avaliação humana.
