# Pendências humanas antes da submissão

1. Confirmar os e-mails institucionais dos três integrantes e preencher os campos marcados no relatório e nos cabeçalhos do código.
2. Os integrantes devem revisar a metodologia, a interpretação dos resultados, o texto e assumir a versão final submetida.
3. Gravar e publicar o vídeo em modo **Público** no YouTube, com duração máxima de cinco minutos.
4. Substituir o campo de URL do vídeo no relatório (`relatorio_projeto_n2.docx` e `.md`) e no README pelo endereço público real.
5. Adicionar ao repositório público os arquivos deste pacote, preservando a pasta `n2` já existente e mantendo a implementação complementar em `n2_entrega/`.
6. Executar a instalação e a demonstração no computador que será usado na apresentação.
