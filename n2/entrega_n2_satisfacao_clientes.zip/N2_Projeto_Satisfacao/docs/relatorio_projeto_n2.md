# Predição da satisfação de clientes a partir de características do atendimento utilizando Machine Learning

**Integrantes**  
Alan Ribeiro do Carmo — RA 10428496 — e-mail institucional: [confirmar]  
Jean Pazzini Domingues — RA 10428555 — e-mail institucional: [confirmar]  
Wendell Rodrigues da Costa — RA 10420319 — e-mail institucional: [confirmar]  

**Docente:** Prof. Dr. Leandro Zerbinatti — leandro.zerbinatti@mackenzie.br  
**Curso:** Sistemas de Informação — 7ºJ — Noturno  
**Instituição:** Faculdade de Computação e Informática, Universidade Presbiteriana Mackenzie — São Paulo, SP — Brasil  
**Ano:** 2026

## Resumo

Este projeto desenvolve uma solução de classificação supervisionada para estimar a satisfação de clientes a partir de características do atendimento. A base, coletada por questionário e anonimizada conforme a documentação do grupo, contém 207 respostas e 11 colunas. Na auditoria, não foram observados valores ausentes, linhas duplicadas ou identificadores repetidos; foram, contudo, identificadas 31 divergências entre o rótulo de satisfação fornecido no arquivo e a regra definida para a nota do atendimento. Por esse motivo, o alvo foi derivado diretamente da nota: valores de 1 a 3 representam “Não satisfeito” e valores 4 ou 5 representam “Satisfeito”. Foram utilizadas sete características do atendimento, excluindo o identificador, a nota que origina o alvo, o rótulo original e a intenção de recompra. A metodologia comparou regressão logística, árvore de decisão e Random Forest com um baseline majoritário. Os dados foram separados em treino e teste, com estratificação, e a seleção de hiperparâmetros foi realizada por validação cruzada estratificada de cinco partes, usando F1-macro. O Random Forest obteve o maior F1-macro médio na validação cruzada (0,754) e foi selecionado. No teste, alcançou acurácia de 76,2%, acurácia balanceada de 76,8%, F1-macro de 70,8% e ROC-AUC de 91,9%. Os resultados demonstram viabilidade experimental, mas também evidenciam limitações relacionadas ao tamanho e ao desequilíbrio da amostra, exigindo validação adicional antes de qualquer uso operacional.

**Palavras-chave:** satisfação de clientes; aprendizado de máquina; classificação supervisionada; atendimento ao cliente.

## Abstract

This project develops a supervised classification solution to estimate customer satisfaction from customer-service characteristics. The dataset, collected through a questionnaire and anonymized according to the group's documentation, contains 207 responses and 11 columns. The data audit found no missing values, duplicated rows, or repeated identifiers; however, 31 discrepancies were identified between the satisfaction label provided in the file and the rule defined from the service rating. Therefore, the target was derived directly from the rating: values from 1 to 3 represent “Not satisfied”, while values 4 or 5 represent “Satisfied”. Seven service-related features were used, excluding the response identifier, the rating used to derive the target, the original label, and repurchase intention. The methodology compared logistic regression, decision tree, and Random Forest models against a majority-class baseline. The dataset was split into stratified training and test sets, and hyperparameter selection was performed through five-fold stratified cross-validation using macro F1. Random Forest achieved the highest mean macro F1 in cross-validation (0.754) and was selected. On the test set, it reached 76.2% accuracy, 76.8% balanced accuracy, 70.8% macro F1, and 91.9% ROC-AUC. The results demonstrate experimental feasibility but also highlight limitations related to sample size and class imbalance, requiring further validation before any operational use.

**Keywords:** customer satisfaction; machine learning; supervised classification; customer service.

## 1. Introdução

### 1.1 Contextualização

A satisfação de clientes é um indicador relevante para avaliar a experiência oferecida durante o atendimento. Elementos como canal de contato, tempo de espera, resolução do problema, necessidade de contato adicional, cordialidade e facilidade percebida podem estar associados à avaliação registrada pelo consumidor. Em operações de atendimento, a identificação de padrões nesses dados pode apoiar análises sobre a experiência e ajudar equipes a investigar situações que mereçam atenção.

Técnicas de aprendizado de máquina permitem construir classificadores a partir de exemplos rotulados. Em classificação supervisionada, o algoritmo recebe observações com atributos e classes conhecidas e aprende uma função capaz de estimar a classe de novos registros. Bibliotecas como scikit-learn oferecem componentes para preparação, treinamento, validação e avaliação desses modelos (PEDREGOSA et al., 2011).

### 1.2 Justificativa

No N1, o grupo realizou a proposta, a análise exploratória e a preparação inicial da base. A etapa N2 é necessária para verificar se as variáveis documentadas oferecem informação preditiva sobre a classe de satisfação e para comparar algoritmos sob um procedimento de avaliação reproduzível. A escolha de métricas além da acurácia é importante porque a distribuição das classes é desigual: há mais respostas classificadas como satisfeitas do que como não satisfeitas. Em conjuntos desbalanceados, a acurácia isolada pode ocultar o desempenho insuficiente na classe minoritária (HE; GARCIA, 2009).

### 1.3 Objetivo

Desenvolver e avaliar modelos de classificação supervisionada capazes de estimar a satisfação de clientes a partir de características relacionadas ao atendimento, utilizando a base coletada pelo grupo.

Como objetivos específicos, foram definidos: (i) auditar e validar o conjunto de dados; (ii) derivar o alvo de acordo com a regra definida no N1; (iii) preparar variáveis numéricas e categóricas sem utilizar informações que revelem diretamente a classe; (iv) treinar e comparar regressão logística, árvore de decisão e Random Forest; (v) avaliar os modelos com métricas adequadas ao desequilíbrio de classes; e (vi) disponibilizar um artefato demonstrativo de previsão e os arquivos necessários à reprodução.

### 1.4 Opção do projeto

O projeto segue a **Opção Framework** prevista no enunciado da disciplina, utilizando Python e scikit-learn para uma tarefa de classificação supervisionada.

### 1.5 Descrição do problema

O problema investigado é: **em que medida características do atendimento permitem estimar se uma resposta será classificada como satisfeita ou não satisfeita?** A variável-alvo é binária e deriva da coluna `Nota_para_o_atendimento_1_a_5`: notas 1, 2 ou 3 recebem classe 0 (`Nao-Satisfeito`), enquanto notas 4 ou 5 recebem classe 1 (`Satisfeito`). A coluna `Satisfacao` existente no CSV não foi utilizada como alvo de treinamento porque a auditoria do N1 identificou divergências em relação a essa regra.

### 1.6 Aspectos éticos e responsabilidade

O arquivo analisado não contém nomes ou identificadores pessoais diretos, e o campo `ID_Resposta` é utilizado apenas para auditoria, não como variável de entrada. Ainda assim, a anonimização não elimina todos os riscos: a faixa etária é uma característica demográfica e pode contribuir para padrões discriminatórios se for utilizada sem avaliação crítica. Além disso, a amostra é pequena, pode refletir viés de seleção e não representa necessariamente toda a população de clientes.

O modelo é experimental e acadêmico. Suas saídas não devem ser utilizadas para negar atendimento, priorizar ou penalizar pessoas, nem substituir a avaliação humana. Uma eventual aplicação real exigiria autorização e governança sobre os dados, transparência sobre a finalidade, controles de acesso, avaliação de vieses por grupos, monitoramento de mudanças no perfil dos dados e validação em amostra externa. As relações encontradas são associativas e preditivas; não demonstram que uma variável cause satisfação ou insatisfação.

## 2. Referencial teórico

### 2.1 Classificação supervisionada

A classificação supervisionada é uma tarefa de aprendizado na qual o modelo aprende a relacionar atributos de entrada a uma classe previamente definida. O procedimento envolve a preparação dos dados, a divisão entre treino e teste, o ajuste dos parâmetros do modelo e a avaliação em observações não utilizadas no treinamento. A implementação foi realizada com scikit-learn, que fornece estimadores, transformadores e pipelines para organizar essas etapas de maneira reproduzível (PEDREGOSA et al., 2011).

### 2.2 Algoritmos comparados

A regressão logística estima a probabilidade de uma observação pertencer a uma classe e constitui uma referência clássica para problemas binários. A árvore de decisão produz regras hierárquicas de divisão dos atributos e oferece uma representação interpretável, embora possa apresentar instabilidade quando a amostra é pequena. O Random Forest combina múltiplas árvores treinadas com amostras e subconjuntos aleatórios de atributos, buscando reduzir a variância de uma árvore individual (BREIMAN, 2001).

### 2.3 Avaliação e desequilíbrio entre classes

A acurácia representa a proporção total de previsões corretas. Precisão mede a proporção de previsões positivas que estão corretas, enquanto revocação (recall) mede a proporção dos positivos reais identificados. O F1 combina precisão e revocação por média harmônica; o F1-macro calcula o F1 de cada classe e atribui o mesmo peso às classes. A acurácia balanceada calcula a média da revocação por classe. A curva ROC e sua área (ROC-AUC) avaliam a capacidade de ordenar exemplos positivos acima dos negativos em diferentes limiares (FAWCETT, 2006).

Essas métricas são relevantes neste projeto porque 78,7% dos registros pertencem à classe “Satisfeito”. Um classificador que escolha sempre a classe majoritária pode obter acurácia aparentemente alta sem identificar os registros não satisfeitos. A análise conjunta de F1-macro, acurácia balanceada, precisão, recall e ROC-AUC permite uma leitura mais equilibrada dos erros (HE; GARCIA, 2009).

## 3. Metodologia

### 3.1 Tipo de pesquisa e ambiente

Trata-se de um estudo aplicado, quantitativo e experimental, com desenvolvimento e comparação de modelos de classificação. A implementação foi realizada em Python, utilizando pandas, NumPy, Matplotlib e scikit-learn. Os pipelines de preparação e classificação são mantidos juntos para que os transformadores sejam ajustados somente nos dados de treino de cada partição.

### 3.2 Dataset e auditoria

A base `dataset_satisfacao_atendimento.csv` foi coletada pelo grupo por meio de questionário, conforme descrito no material do N1. Contém 207 respostas e 11 colunas. A auditoria reproduzida na N2 encontrou zero valores ausentes, zero linhas duplicadas, zero IDs duplicados e zero notas fora do intervalo de 1 a 5.

Foram identificadas 31 divergências entre a coluna original `Satisfacao` e a regra oficial baseada na nota: 28 registros com nota 4 rotulados originalmente como `Nao-Satisfeito`, dois registros com nota 5 rotulados como `Nao-Satisfeito` e um registro com nota 3 rotulado como `Satisfeito`. Por isso, a coluna bruta foi preservada sem alteração e o alvo foi recalculado em memória pela regra documentada.

A distribuição resultante foi de 44 observações `Nao-Satisfeito` (21,3%) e 163 observações `Satisfeito` (78,7%). A presença dessa assimetria foi considerada durante a escolha das métricas e na análise do baseline.

### 3.3 Variáveis utilizadas e prevenção de vazamento

Foram utilizadas sete features: `Faixa_etaria`, `Canal_de_atendimento`, `Tempo_de_espera_minutos`, `Problema_foi_resolvido`, `Precisou_contato_novamente`, `Atendimento_foi_cordial` e `Facilidade_para_resolver_1_a_5`.

Foram excluídas `ID_Resposta`, por ser identificador técnico; `Nota_para_o_atendimento_1_a_5`, por originar diretamente a classe; `Satisfacao`, por conter inconsistências auditadas; e `Voltaria_a_comprar`, por representar uma possível consequência da experiência e não uma característica de atendimento apropriada para a previsão pretendida. Essa separação evita que o modelo receba diretamente o valor usado para construir o target ou informações que possam revelar o resultado.

As variáveis categóricas foram codificadas com One-Hot Encoding, permitindo que o modelo trabalhe com categorias sem impor uma ordem artificial. O pipeline prevê imputação numérica pela mediana e categórica pela categoria mais frequente, além de padronização das variáveis numéricas. Como a auditoria não encontrou valores ausentes nesta base, não foi necessária imputação efetiva. As transformações foram implementadas em `ColumnTransformer` dentro de `Pipeline`, evitando que estatísticas do conjunto de teste contaminem o treinamento.

### 3.4 Treinamento e validação

A base foi dividida em 80% para treino (165 registros) e 20% para teste (42 registros), utilizando estratificação e `random_state=42`. No conjunto de treino, os hiperparâmetros foram pesquisados com `GridSearchCV` e `StratifiedKFold` de cinco partes, com embaralhamento. O critério de seleção foi F1-macro.

Foram comparados: (i) um baseline `DummyClassifier` que sempre prevê a classe majoritária; (ii) regressão logística; (iii) árvore de decisão; e (iv) Random Forest. As grades de hiperparâmetros e as melhores configurações são registradas em `n2_entrega/results/metrics/comparacao_modelos.csv`. O modelo final salvo foi escolhido pelo maior F1-macro médio na validação cruzada do treino. O conjunto de teste foi reservado para a avaliação final e não participou da seleção dos hiperparâmetros.

### 3.5 Métricas

Foram calculadas acurácia, acurácia balanceada, precisão, recall e F1 para a classe positiva (`Satisfeito`), F1-macro e ROC-AUC. Também foram salvas a matriz de confusão, o relatório por classe e a importância por permutação. A última análise é tratada como exploratória, pois o conjunto de teste contém apenas 42 observações.

## 4. Resultados e discussão

### 4.1 Comparação dos modelos

A Tabela 1 apresenta a média de F1-macro obtida na validação cruzada do treino e as métricas medidas no conjunto de teste. Os valores são apresentados como proporções entre 0 e 1.

| Modelo | F1-macro CV (treino) | Acurácia teste | Acurácia balanceada | F1-macro teste | ROC-AUC |
|---|---:|---:|---:|---:|---:|
| Random Forest | 0,7538 | 0,7619 | 0,7677 | 0,7083 | 0,9192 |
| Regressão Logística | 0,7261 | 0,9286 | 0,8737 | 0,8894 | 0,9226 |
| Árvore de Decisão | 0,6994 | 0,9048 | 0,8586 | 0,8586 | 0,8889 |
| Baseline majoritário | — | 0,7857 | 0,5000 | 0,4400 | 0,5000 |

**Fonte:** resultados da execução reproduzível do projeto (2026).

O Random Forest obteve a maior média de F1-macro na validação cruzada do conjunto de treino (0,7538) e foi selecionado para compor o artefato de previsão. No conjunto de teste, entretanto, a regressão logística apresentou as melhores métricas pontuais (acurácia de 92,9% e F1-macro de 0,8894), seguida pela árvore de decisão. O Random Forest atingiu F1-macro de 0,7083. Essa diferença entre validação cruzada e teste mostra a variabilidade esperada em uma amostra pequena: não se deve interpretar a escolha do Random Forest como evidência de superioridade geral. A decisão de seleção foi mantida conforme o critério predefinido de validação cruzada, sem escolher o algoritmo retrospectivamente pelo resultado do teste.

O baseline majoritário obteve acurácia de 78,6%, maior que os 76,2% do Random Forest, mas sua acurácia balanceada foi 0,50 e seu F1-macro 0,44. Isso ocorre porque o baseline sempre prevê a classe “Satisfeito” e não identifica a classe minoritária. O Random Forest reduz esse problema, alcançando acurácia balanceada de 0,7677 e F1-macro de 0,7083. Portanto, a acurácia isolada não seria suficiente para comparar os modelos.

### 4.2 Avaliação do modelo selecionado

O Random Forest selecionado utiliza 200 árvores, `max_depth=None`, `min_samples_leaf=4` e `class_weight=balanced_subsample`. No conjunto de teste, apresentou acurácia de 0,7619, acurácia balanceada de 0,7677, precisão para a classe `Satisfeito` de 0,9259, recall de 0,7576, F1 da classe positiva de 0,8333, F1-macro de 0,7083 e ROC-AUC de 0,9192.

A matriz de confusão registrou sete não satisfeitos corretamente identificados, dois não satisfeitos previstos como satisfeitos, oito satisfeitos previstos como não satisfeitos e 25 satisfeitos corretamente identificados. Em termos práticos, o modelo reconheceu 7 dos 9 registros não satisfeitos no teste e 25 dos 33 registros satisfeitos. O número reduzido de casos em cada classe no teste exige cautela ao interpretar essas proporções.

### 4.3 Importância por permutação

A análise de importância por permutação apresentou uma pequena importância média positiva para `Precisou_contato_novamente` (+0,0286 em F1-macro). As demais variáveis tiveram valores médios negativos nesta execução. Isso não significa que tenham efeito causal negativo: indica apenas que, ao embaralhá-las neste conjunto de teste pequeno e nesta execução, não foi observada melhora do F1-macro. A instabilidade e a baixa quantidade de observações impedem conclusões firmes sobre a contribuição individual das variáveis.

### 4.4 Artefato demonstrativo

Após a avaliação independente no conjunto de teste, uma cópia do pipeline selecionado foi reajustada com os 207 registros e serializada em `n2_entrega/results/models/modelo_satisfacao.joblib`. As métricas apresentadas neste relatório continuam sendo as obtidas antes desse reajuste: o modelo foi ajustado em 165 registros e avaliado nos 42 registros reservados. O projeto disponibiliza uma demonstração por terminal (`python n2_entrega/predict.py`) e uma interface Streamlit (`streamlit run n2_entrega/app_streamlit.py`). A interface recebe as sete características e exibe a classe estimada e a probabilidade estimada de pertencer à classe `Satisfeito`. A probabilidade é uma saída do modelo, não uma certeza sobre a opinião do cliente.

### 4.5 Limitações

As principais limitações são: (i) amostra pequena, com somente 207 respostas; (ii) desequilíbrio entre classes; (iii) possível viés de seleção decorrente do processo de coleta por questionário; (iv) ausência de validação externa em uma segunda coleta independente; (v) instabilidade das métricas e da importância das variáveis em partições pequenas; e (vi) ausência de informação suficiente no material disponibilizado para caracterizar detalhadamente a população de origem e o contexto empresarial da coleta. Os resultados devem ser considerados experimentais e não generalizados para outras empresas ou públicos.

## 5. Conclusão

O projeto desenvolveu uma solução de classificação supervisionada para estimar a satisfação de clientes com base em características do atendimento. O conjunto de dados foi auditado, o alvo foi derivado pela regra definida no N1 e foram comparados um baseline majoritário, regressão logística, árvore de decisão e Random Forest. O processo utilizou divisão estratificada entre treino e teste, validação cruzada no treino e métricas que consideram o desequilíbrio de classes.

O Random Forest apresentou a maior média de F1-macro na validação cruzada (0,7538) e foi selecionado para a demonstração. No teste, alcançou F1-macro de 0,7083, acurácia balanceada de 0,7677 e ROC-AUC de 0,9192. Embora a regressão logística tenha apresentado resultado pontual superior no conjunto de teste, a seleção foi mantida pelo critério de validação cruzada previamente estabelecido. O baseline mostrou por que a acurácia isolada não é adequada para este cenário: mesmo com acurácia de 78,6%, não reconheceu a classe minoritária.

Assim, o objetivo foi alcançado em caráter experimental: foram implementados e avaliados classificadores e foi disponibilizado um artefato demonstrativo. Entretanto, os resultados não autorizam uso operacional. Como continuidade, recomenda-se ampliar a amostra, documentar melhor a população e o contexto da coleta, executar validação externa, avaliar estabilidade por subgrupos, revisar os custos dos diferentes tipos de erro e recalibrar o modelo antes de qualquer aplicação prática.

## 6. Endereços do projeto

**GitHub:** https://github.com/Lucas3462/previsao-satisfacao-clientes-ml  
**Vídeo no YouTube:** [INSERIR A URL PÚBLICA DO VÍDEO APÓS A GRAVAÇÃO E PUBLICAÇÃO]  

O vídeo deve ser publicado em modo público e ter duração máxima de cinco minutos, conforme o enunciado da disciplina. O endereço deverá ser inserido nesta seção antes do envio definitivo do relatório.

## 7. Referências bibliográficas

BREIMAN, Leo. Random forests. *Machine Learning*, v. 45, p. 5-32, 2001. DOI: https://doi.org/10.1023/A:1010933404324.

FAWCETT, Tom. An introduction to ROC analysis. *Pattern Recognition Letters*, v. 27, n. 8, p. 861-874, 2006. DOI: https://doi.org/10.1016/j.patrec.2005.10.010.

HE, Haibo; GARCIA, Edwardo A. Learning from imbalanced data. *IEEE Transactions on Knowledge and Data Engineering*, v. 21, n. 9, p. 1263-1284, 2009. DOI: https://doi.org/10.1109/TKDE.2008.239.

PEDREGOSA, Fabian et al. Scikit-learn: Machine Learning in Python. *Journal of Machine Learning Research*, v. 12, n. 85, p. 2825-2830, 2011.

RIBEIRO DO CARMO, Alan; DOMINGUES, Jean Pazzini; COSTA, Wendell Rodrigues da. *Relatório do projeto de Inteligência Artificial - N1: Predição da satisfação de clientes a partir de características do atendimento utilizando Machine Learning*. Universidade Presbiteriana Mackenzie, 2026. Disponível em: https://github.com/Lucas3462/previsao-satisfacao-clientes-ml.

UNIVERSIDADE PRESBITERIANA MACKENZIE. Faculdade de Computação e Informática. *Projeto da disciplina: Aplicação de Inteligência Artificial em Problema Real - 7ºJ SI - Noite*. São Paulo, 2026. Documento fornecido pelo docente.
