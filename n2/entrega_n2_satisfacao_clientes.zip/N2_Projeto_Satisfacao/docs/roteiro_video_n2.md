# Roteiro do vídeo — Projeto N2

**Projeto:** Predição da satisfação de clientes a partir de características do atendimento utilizando Machine Learning  
**Duração planejada:** 4min50s (o limite do enunciado é 5 minutos)  
**Integrantes:** Alan Ribeiro do Carmo (RA 10428496), Jean Pazzini Domingues (RA 10428555) e Wendell Rodrigues da Costa (RA 10420319)  
**Professor:** Prof. Dr. Leandro Zerbinatti  
**Disciplina/curso:** Inteligência Artificial — Sistemas de Informação — 7ºJ — Noturno  
**Instituição:** Universidade Presbiteriana Mackenzie — FCI

## Preparação antes de gravar

1. Na raiz do projeto, instale as dependências e gere novamente os resultados:
   ```bash
   python -m pip install -r requirements.txt
   python run_n2.py
   ```
2. Abra a aplicação demonstrativa:
   ```bash
   streamlit run n2_entrega/app_streamlit.py
   ```
3. Deixe o repositório GitHub aberto em outra aba. Tenha o relatório, o notebook e `n2_entrega/results/metrics/comparacao_modelos.csv` disponíveis.
4. Faça um teste curto de áudio e tela. Não deixe o vídeo ultrapassar cinco minutos.

## Roteiro cronometrado

### 0:00–0:25 | Abertura e identificação
**Na tela:** capa com o título, nomes dos integrantes, disciplina, professor, curso e instituição.

**Fala sugerida:**
> Olá! Nós somos Alan Ribeiro do Carmo, Jean Pazzini Domingues e Wendell Rodrigues da Costa, alunos de Sistemas de Informação da Universidade Presbiteriana Mackenzie. Este é o projeto da disciplina Inteligência Artificial, ministrada pelo professor Leandro Zerbinatti. Nosso trabalho é a previsão da satisfação de clientes a partir de características do atendimento, utilizando Machine Learning.

### 0:25–0:55 | Problema e objetivo
**Na tela:** apresentar a pergunta de pesquisa.

**Fala sugerida:**
> O problema que investigamos é se informações sobre o atendimento, como canal utilizado, tempo de espera, resolução do problema e cordialidade, permitem estimar se um cliente ficará satisfeito ou não. Nosso objetivo foi desenvolver e avaliar modelos de classificação supervisionada para realizar essa estimativa.

### 0:55–1:30 | Dataset e preparação
**Na tela:** mostrar o CSV e o gráfico de distribuição das classes.

**Fala sugerida:**
> Utilizamos a base coletada pelo grupo por questionário, com 207 respostas. Na auditoria, não encontramos valores ausentes nem registros duplicados. Identificamos 31 divergências na coluna de satisfação original. Por isso, seguimos a regra documentada no N1: notas de 1 a 3 foram classificadas como não satisfeitas e notas 4 ou 5 como satisfeitas. O conjunto ficou com 44 registros não satisfeitos e 163 satisfeitos. Excluímos identificador, nota, rótulo original e intenção de recompra das variáveis de entrada para evitar vazamento de informação.

### 1:30–2:25 | Metodologia e algoritmos
**Na tela:** mostrar o notebook e a seção de metodologia.

**Fala sugerida:**
> Utilizamos sete características do atendimento. As variáveis categóricas foram transformadas por One-Hot Encoding e as numéricas foram padronizadas, dentro de pipelines do scikit-learn. Separamos 80% dos dados para treino e 20% para teste, com estratificação. No treino, usamos validação cruzada estratificada de cinco partes e busca de hiperparâmetros com F1-macro. Comparamos um baseline majoritário, regressão logística, árvore de decisão e Random Forest. A escolha do modelo final foi feita pelo resultado médio da validação cruzada, deixando o conjunto de teste reservado para avaliação.

### 2:25–3:25 | Resultados e interpretação
**Na tela:** apresentar a tabela de comparação, a matriz de confusão e a curva ROC.

**Fala sugerida:**
> O Random Forest obteve o maior F1-macro médio na validação cruzada, aproximadamente 0,754, e por isso foi selecionado para a demonstração. No conjunto de teste, alcançou acurácia balanceada de 0,768, F1-macro de 0,708 e ROC-AUC de 0,919. É importante destacar que a regressão logística teve resultado pontual superior nesse conjunto de teste. Mantivemos a seleção pelo critério definido antes da avaliação, baseado na validação cruzada, e isso mostra a instabilidade que pode ocorrer com uma amostra pequena. O baseline teve acurácia de 78,6%, mas não identificou a classe minoritária. Por isso, analisamos também F1-macro e acurácia balanceada, e não apenas acurácia.

### 3:25–4:20 | Demonstração do artefato
**Na tela:** abrir o Streamlit. Usar os valores do exemplo: faixa 26-40; canal WhatsApp; espera 5 minutos; problema resolvido Sim; novo contato Não; cordialidade Sim; facilidade 4. Clicar em **Prever satisfação**.

**Fala sugerida:**
> Aqui está a interface demonstrativa. Informamos características de um atendimento e o pipeline treinado retorna uma classe estimada e a probabilidade estimada de satisfação. Neste exemplo, o resultado é Satisfeito. Essa probabilidade não é uma certeza nem deve ser usada para tomar decisões automáticas sobre clientes; trata-se de uma demonstração acadêmica.

### 4:20–4:50 | GitHub e encerramento
**Na tela:** abrir o repositório e mostrar README, pasta `n2_entrega`, notebook, resultados, modelo e relatório.

**Fala sugerida:**
> Todo o material do projeto está organizado no GitHub: dataset, código-fonte, notebook, métricas, gráficos, modelo treinado, interface e relatório. Concluímos que a classificação é tecnicamente viável como experimento, mas a amostra pequena e o desequilíbrio das classes exigem mais dados e validação externa antes de qualquer uso real. Obrigado!

## Checklist final de publicação

- [ ] Todos os integrantes revisaram e aprovaram a versão final.
- [ ] O vídeo contém os itens exigidos no enunciado e tem, no máximo, cinco minutos.
- [ ] A demonstração mostrada no vídeo foi executada na versão final do código.
- [ ] O vídeo foi publicado como **Público** no YouTube de um dos integrantes.
- [ ] A URL pública foi inserida na seção de endereços do relatório e no README.
- [ ] Os e-mails institucionais dos três alunos foram confirmados e preenchidos no relatório.
