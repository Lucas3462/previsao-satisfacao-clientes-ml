# N2 - Desenvolvimento, treinamento e avaliação

Esta pasta contém a implementação final de apoio à etapa N2, isolada em `n2_entrega/` para preservar a pasta `n2/` que já existe no repositório.

## Execução

A partir da raiz do repositório:

```bash
python -m pip install -r requirements.txt
python run_n2.py
```

A execução recria os relatórios e gráficos em `n2_entrega/results/`. Após calcular as métricas com o teste reservado, reajusta uma cópia do pipeline selecionado com todos os 207 registros e grava o modelo demonstrativo em `n2_entrega/results/models/modelo_satisfacao.joblib`. As métricas de teste permanecem associadas ao modelo que foi ajustado apenas nos 165 registros de treino.

## Artefatos

- `src/modeling.py`: validação do dataset, criação do alvo, preprocessamento, pipelines, GridSearchCV, métricas e gráficos.
- `notebooks/03_modelagem_e_avaliacao.ipynb`: notebook da N2.
- `predict.py`: demonstração simples via terminal.
- `app_streamlit.py`: interface para simular entradas e visualizar a previsão.
- `results/metrics/`: arquivos CSV e JSON com números e auditoria.
- `results/figures/`: distribuição das classes, comparação de F1-macro, matriz de confusão, curva ROC e importância por permutação.
- `results/models/`: modelo serializado.

## Modelo e avaliação

O executor compara baseline majoritário, regressão logística, árvore de decisão e Random Forest. A seleção ocorre pelo maior F1-macro médio na validação cruzada de cinco partes aplicada ao treino. O conjunto de teste fica separado para avaliação final. As métricas e limitações são descritas no relatório completo em `docs/relatorio_projeto_n2.docx`.

A amostra contém 207 registros e é desbalanceada (44 não satisfeitos; 163 satisfeitos). Portanto, não interpretar a acurácia isoladamente. Este é um artefato acadêmico e experimental, não adequado para decisões automáticas sobre clientes.

## Identificação e histórico

Integrantes: Alan Ribeiro do Carmo (RA 10428496), Jean Pazzini Domingues (RA 10428555) e Wendell Rodrigues da Costa (RA 10420319). Docente: Prof. Dr. Leandro Zerbinatti.

Histórico da implementação inicial: 2026-11-12 — assistência de IA na preparação de uma versão de apoio; revisão e validação pelos integrantes pendentes.
