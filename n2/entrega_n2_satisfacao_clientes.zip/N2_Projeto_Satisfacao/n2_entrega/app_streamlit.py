"""Interface demonstrativa Streamlit para testar o modelo da N2.

Integrantes: Alan Ribeiro do Carmo (RA 10428496), Jean Pazzini Domingues
(RA 10428555) e Wendell Rodrigues da Costa (RA 10420319).
E-mails institucionais dos alunos: [CONFIRMAR E INSERIR OS TRES ENDERECOS].
Docente: Prof. Dr. Leandro Zerbinatti.
Sintese: formulario simples para simular a classificacao de um atendimento.
Historico:
- 2026-11-12 | Assistencia de IA (versao de apoio) | Criacao da interface;
  revisar e validar pelos integrantes antes da entrega.
"""
from pathlib import Path
import joblib
import pandas as pd
import streamlit as st

ROOT = Path(__file__).resolve().parents[1]
MODEL_PATH = ROOT / "n2_entrega" / "results" / "models" / "modelo_satisfacao.joblib"

st.set_page_config(page_title="Previsao de satisfacao", page_icon="📊", layout="centered")
st.title("Previsao da satisfacao de clientes")
st.caption("Demonstracao academica de classificacao supervisionada")

if not MODEL_PATH.exists():
    st.error("Modelo ainda nao encontrado. Execute primeiro `python run_n2.py` na raiz do projeto.")
    st.stop()

artifact = joblib.load(MODEL_PATH)
model = artifact["model"]
st.info(f"Modelo carregado: **{artifact['model_name']}**")

with st.form("form_atendimento"):
    faixa = st.selectbox("Faixa etaria", ["18-25", "26-40", "41-60", "60+"])
    canal = st.selectbox("Canal de atendimento", ["WhatsApp", "Telefone", "Chat no site", "E-mail", "Presencial"])
    tempo = st.number_input("Tempo de espera (minutos)", min_value=0.0, max_value=600.0, value=5.0, step=1.0)
    resolvido = st.selectbox("O problema foi resolvido?", ["Sim", "Nao"])
    novo_contato = st.selectbox("Precisou entrar em contato novamente?", ["Nao", "Sim"])
    cordial = st.selectbox("O atendimento foi cordial?", ["Sim", "Nao"])
    facilidade = st.slider("Facilidade para resolver (1 a 5)", 1, 5, 4)
    submitted = st.form_submit_button("Prever satisfacao", type="primary")

if submitted:
    sample = pd.DataFrame([{
        "Faixa_etaria": faixa,
        "Canal_de_atendimento": canal,
        "Tempo_de_espera_minutos": tempo,
        "Problema_foi_resolvido": resolvido,
        "Precisou_contato_novamente": novo_contato,
        "Atendimento_foi_cordial": cordial,
        "Facilidade_para_resolver_1_a_5": facilidade,
    }])
    pred = int(model.predict(sample)[0])
    p_sat = float(model.predict_proba(sample)[0, 1])
    if pred == 1:
        st.success("Classificacao estimada: SATISFEITO")
    else:
        st.warning("Classificacao estimada: NAO-SATISFEITO")
    st.metric("Probabilidade estimada de satisfacao", f"{p_sat:.1%}")
    st.caption("A probabilidade e uma estimativa do modelo, nao uma certeza sobre a opiniao real do cliente.")

st.divider()
st.caption("Uso academico. A amostra e pequena, possui desequilibrio entre classes e nao representa necessariamente todos os clientes. A previsao nao deve ser usada isoladamente para decisoes." )
