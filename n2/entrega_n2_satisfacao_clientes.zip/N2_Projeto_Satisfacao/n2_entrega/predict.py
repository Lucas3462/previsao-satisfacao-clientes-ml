"""Exemplo de predicao individual usando o modelo salvo na N2.

Integrantes: Alan Ribeiro do Carmo (RA 10428496), Jean Pazzini Domingues
(RA 10428555) e Wendell Rodrigues da Costa (RA 10420319).
E-mails institucionais dos alunos: [CONFIRMAR E INSERIR OS TRES ENDERECOS].
Docente: Prof. Dr. Leandro Zerbinatti.
Sintese: carrega o pipeline final e classifica um atendimento informado via terminal.
Historico:
- 2026-11-12 | Assistencia de IA (versao de apoio) | Criacao da demonstracao CLI.
"""
from __future__ import annotations

import argparse
from pathlib import Path
import sys

import joblib
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
MODEL_PATH = ROOT / "n2_entrega" / "results" / "models" / "modelo_satisfacao.joblib"


def main() -> int:
    parser = argparse.ArgumentParser(description="Prediz a satisfacao de um atendimento.")
    parser.add_argument("--faixa-etaria", default="26-40")
    parser.add_argument("--canal", default="WhatsApp")
    parser.add_argument("--tempo-espera", type=float, default=5)
    parser.add_argument("--resolvido", choices=["Sim", "Nao"], default="Sim")
    parser.add_argument("--novo-contato", choices=["Sim", "Nao"], default="Nao")
    parser.add_argument("--cordial", choices=["Sim", "Nao"], default="Sim")
    parser.add_argument("--facilidade", type=int, choices=[1, 2, 3, 4, 5], default=4)
    args = parser.parse_args()

    if not MODEL_PATH.exists():
        print("Modelo nao encontrado. Execute primeiro: python run_n2.py", file=sys.stderr)
        return 1
    if args.tempo_espera < 0:
        parser.error("O tempo de espera nao pode ser negativo.")

    artifact = joblib.load(MODEL_PATH)
    model = artifact["model"]
    sample = pd.DataFrame(
        [
            {
                "Faixa_etaria": args.faixa_etaria,
                "Canal_de_atendimento": args.canal,
                "Tempo_de_espera_minutos": args.tempo_espera,
                "Problema_foi_resolvido": args.resolvido,
                "Precisou_contato_novamente": args.novo_contato,
                "Atendimento_foi_cordial": args.cordial,
                "Facilidade_para_resolver_1_a_5": args.facilidade,
            }
        ]
    )
    predicted = int(model.predict(sample)[0])
    probability = float(model.predict_proba(sample)[0, 1])
    label = "Satisfeito" if predicted == 1 else "Nao-Satisfeito"
    print(f"Modelo: {artifact['model_name']}")
    print(f"Classe estimada: {label}")
    print(f"Probabilidade estimada da classe Satisfeito: {probability:.1%}")
    print("Aviso: demonstracao academica; nao utilizar como decisao automatizada sobre clientes.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
