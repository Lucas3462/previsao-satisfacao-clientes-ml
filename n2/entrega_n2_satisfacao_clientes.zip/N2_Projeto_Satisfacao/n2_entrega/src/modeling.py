"""Modelos supervisionados para previsao da satisfacao de clientes.

Integrantes: Alan Ribeiro do Carmo (RA 10428496), Jean Pazzini Domingues
(RA 10428555) e Wendell Rodrigues da Costa (RA 10420319).
E-mails institucionais dos alunos: [CONFIRMAR E INSERIR OS TRES ENDERECOS].
Docente: Prof. Dr. Leandro Zerbinatti.
Sintese: prepara os dados, compara classificadores e salva metricas, figuras e modelo.
Historico:
- 2026-11-12 | Assistencia de IA (versao de apoio) | Implementacao inicial da N2;
  revisar e validar pelos integrantes antes da entrega.
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import joblib
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.base import clone
from sklearn.compose import ColumnTransformer
from sklearn.dummy import DummyClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.impute import SimpleImputer
from sklearn.inspection import permutation_importance
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    accuracy_score,
    balanced_accuracy_score,
    classification_report,
    confusion_matrix,
    ConfusionMatrixDisplay,
    f1_score,
    precision_score,
    recall_score,
    roc_auc_score,
    RocCurveDisplay,
)
from sklearn.model_selection import GridSearchCV, StratifiedKFold, train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.tree import DecisionTreeClassifier

RANDOM_STATE = 42
TARGET_SOURCE = "Nota_para_o_atendimento_1_a_5"
TARGET_NAME = "Satisfacao_binaria"
CLASS_NAMES = {0: "Nao-Satisfeito", 1: "Satisfeito"}
FEATURES = [
    "Faixa_etaria",
    "Canal_de_atendimento",
    "Tempo_de_espera_minutos",
    "Problema_foi_resolvido",
    "Precisou_contato_novamente",
    "Atendimento_foi_cordial",
    "Facilidade_para_resolver_1_a_5",
]
CATEGORICAL_FEATURES = [
    "Faixa_etaria",
    "Canal_de_atendimento",
    "Problema_foi_resolvido",
    "Precisou_contato_novamente",
    "Atendimento_foi_cordial",
]
NUMERIC_FEATURES = [
    "Tempo_de_espera_minutos",
    "Facilidade_para_resolver_1_a_5",
]


def load_and_validate_dataset(csv_path: Path) -> tuple[pd.DataFrame, pd.Series, dict[str, Any]]:
    """Carrega o CSV, valida campos e deriva o alvo sem usar o rótulo original."""
    if not csv_path.exists():
        raise FileNotFoundError(
            f"Dataset nao encontrado em: {csv_path}. Verifique data/raw/ ou use --data."
        )

    df = pd.read_csv(csv_path, encoding="utf-8-sig")
    required = set(FEATURES + ["ID_Resposta", TARGET_SOURCE, "Satisfacao", "Voltaria_a_comprar"])
    missing_columns = sorted(required.difference(df.columns))
    if missing_columns:
        raise ValueError(f"Colunas obrigatorias ausentes no dataset: {missing_columns}")
    if df.empty:
        raise ValueError("O dataset esta vazio.")
    if df["ID_Resposta"].duplicated().any():
        raise ValueError("Foram encontrados IDs de resposta duplicados.")
    if df[TARGET_SOURCE].isna().any():
        raise ValueError("Ha valores ausentes na nota usada para gerar o alvo.")

    notas = pd.to_numeric(df[TARGET_SOURCE], errors="coerce")
    if notas.isna().any() or not notas.isin([1, 2, 3, 4, 5]).all():
        raise ValueError("A nota do atendimento deve conter apenas valores inteiros de 1 a 5.")

    # Regra oficial definida no N1: notas 1-3 -> 0; notas 4-5 -> 1.
    y = (notas >= 4).astype(int).rename(TARGET_NAME)
    X = df[FEATURES].copy()

    original = df["Satisfacao"].astype(str).str.strip()
    derived_labels = y.map(CLASS_NAMES)
    mismatch = int((original != derived_labels).sum())

    quality = {
        "linhas": int(len(df)),
        "colunas": int(df.shape[1]),
        "valores_ausentes_total": int(df.isna().sum().sum()),
        "linhas_duplicadas": int(df.duplicated().sum()),
        "ids_duplicados": int(df["ID_Resposta"].duplicated().sum()),
        "notas_invalidas": int((~notas.isin([1, 2, 3, 4, 5])).sum()),
        "divergencias_rotulo_original": mismatch,
        "classe_0_nao_satisfeito": int((y == 0).sum()),
        "classe_1_satisfeito": int((y == 1).sum()),
        "features_utilizadas": FEATURES,
        "colunas_excluidas": [
            "ID_Resposta",
            TARGET_SOURCE,
            "Satisfacao",
            "Voltaria_a_comprar",
        ],
        "regra_target": "Nota 1-3 = 0 (Nao-Satisfeito); nota 4-5 = 1 (Satisfeito)",
    }
    return X, y, quality


def build_preprocessor() -> ColumnTransformer:
    """Cria transformacao numerica/categorica dentro do Pipeline anti-leakage."""
    numeric_pipe = Pipeline(
        steps=[
            ("imputer", SimpleImputer(strategy="median")),
            ("scaler", StandardScaler()),
        ]
    )
    categorical_pipe = Pipeline(
        steps=[
            ("imputer", SimpleImputer(strategy="most_frequent")),
            ("onehot", OneHotEncoder(handle_unknown="ignore")),
        ]
    )
    return ColumnTransformer(
        transformers=[
            ("num", numeric_pipe, NUMERIC_FEATURES),
            ("cat", categorical_pipe, CATEGORICAL_FEATURES),
        ],
        remainder="drop",
    )


def model_searches() -> dict[str, tuple[Any, dict[str, list[Any]]]]:
    """Define os modelos e grades pequenos, adequados ao tamanho da amostra."""
    preprocessor = build_preprocessor()
    definitions = {
        "Regressao Logistica": (
            LogisticRegression(max_iter=3000, random_state=RANDOM_STATE),
            {
                "classifier__C": [0.1, 1.0, 10.0],
                "classifier__class_weight": [None, "balanced"],
            },
        ),
        "Arvore de Decisao": (
            DecisionTreeClassifier(random_state=RANDOM_STATE),
            {
                "classifier__max_depth": [2, 3, 5, None],
                "classifier__min_samples_leaf": [2, 4, 8],
                "classifier__class_weight": [None, "balanced"],
            },
        ),
        "Random Forest": (
            RandomForestClassifier(random_state=RANDOM_STATE, n_jobs=1),
            {
                "classifier__n_estimators": [200],
                "classifier__max_depth": [None, 4],
                "classifier__min_samples_leaf": [2, 4],
                "classifier__class_weight": [None, "balanced_subsample"],
            },
        ),
    }
    return {
        name: (Pipeline([("preprocessor", preprocessor), ("classifier", estimator)]), grid)
        for name, (estimator, grid) in definitions.items()
    }


def _metrics(model: Any, X_test: pd.DataFrame, y_test: pd.Series) -> dict[str, float]:
    predictions = model.predict(X_test)
    probabilities = model.predict_proba(X_test)[:, 1]
    return {
        "accuracy": float(accuracy_score(y_test, predictions)),
        "balanced_accuracy": float(balanced_accuracy_score(y_test, predictions)),
        "precision_satisfeito": float(precision_score(y_test, predictions, pos_label=1, zero_division=0)),
        "recall_satisfeito": float(recall_score(y_test, predictions, pos_label=1, zero_division=0)),
        "f1_satisfeito": float(f1_score(y_test, predictions, pos_label=1, zero_division=0)),
        "f1_macro": float(f1_score(y_test, predictions, average="macro", zero_division=0)),
        "roc_auc": float(roc_auc_score(y_test, probabilities)),
    }


def run_experiment(csv_path: Path, output_dir: Path) -> dict[str, Any]:
    """Executa holdout estratificado, CV no treino, busca de hiperparametros e teste."""
    output_dir.mkdir(parents=True, exist_ok=True)
    (output_dir / "metrics").mkdir(exist_ok=True)
    (output_dir / "figures").mkdir(exist_ok=True)
    (output_dir / "models").mkdir(exist_ok=True)

    X, y, quality = load_and_validate_dataset(csv_path)
    X_train, X_test, y_train, y_test = train_test_split(
        X,
        y,
        test_size=0.20,
        random_state=RANDOM_STATE,
        stratify=y,
    )

    cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=RANDOM_STATE)
    comparison: list[dict[str, Any]] = []
    fitted_models: dict[str, Any] = {}

    # Baseline: classificador que sempre escolhe a classe mais frequente no treino.
    baseline = DummyClassifier(strategy="most_frequent")
    baseline.fit(X_train, y_train)
    fitted_models["Baseline majoritaria"] = baseline
    baseline_metrics = _metrics(baseline, X_test, y_test)
    comparison.append(
        {
            "modelo": "Baseline majoritaria",
            "f1_macro_cv_treino": np.nan,
            "melhor_configuracao": "most_frequent",
            **baseline_metrics,
        }
    )

    searches: dict[str, Any] = {}
    for name, (pipeline, param_grid) in model_searches().items():
        search = GridSearchCV(
            estimator=pipeline,
            param_grid=param_grid,
            scoring="f1_macro",
            cv=cv,
            n_jobs=1,
            refit=True,
            error_score="raise",
        )
        search.fit(X_train, y_train)
        searches[name] = search
        fitted_models[name] = search.best_estimator_
        test_metrics = _metrics(search.best_estimator_, X_test, y_test)
        comparison.append(
            {
                "modelo": name,
                "f1_macro_cv_treino": float(search.best_score_),
                "melhor_configuracao": json.dumps(search.best_params_, ensure_ascii=False, default=str),
                **test_metrics,
            }
        )

    comparison_df = pd.DataFrame(comparison).sort_values(
        by=["f1_macro_cv_treino", "f1_macro", "balanced_accuracy"],
        ascending=False,
        na_position="last",
    )
    comparison_df.to_csv(output_dir / "metrics" / "comparacao_modelos.csv", index=False)

    # Selecao do melhor algoritmo pela validacao cruzada restrita ao treino.
    # O conjunto de teste fica reservado para a estimativa final de desempenho.
    best_name = max(searches, key=lambda model_name: searches[model_name].best_score_)
    best_model = fitted_models[best_name]
    best_metrics = _metrics(best_model, X_test, y_test)
    best_predictions = best_model.predict(X_test)

    # Depois de concluir a avaliacao independente, reajusta-se uma copia do
    # pipeline selecionado com todos os 207 registros para a demonstracao.
    # As metricas reportadas abaixo continuam sendo as do modelo treinado
    # somente no conjunto de treino (165) e avaliado no teste (42).
    final_model = clone(best_model)
    final_model.fit(X, y)

    model_path = output_dir / "models" / "modelo_satisfacao.joblib"
    joblib.dump(
        {
            "model": final_model,
            "model_name": best_name,
            "features": FEATURES,
            "class_names": CLASS_NAMES,
            "artifact_training_rows": int(len(X)),
            "artifact_training_scope": "Todos os registros, somente apos a avaliacao independente",
            "holdout_metrics_before_refit": best_metrics,
            "random_state": RANDOM_STATE,
        },
        model_path,
    )

    report = classification_report(
        y_test,
        best_predictions,
        labels=[0, 1],
        target_names=[CLASS_NAMES[0], CLASS_NAMES[1]],
        output_dict=True,
        zero_division=0,
    )
    pd.DataFrame(report).transpose().to_csv(
        output_dir / "metrics" / "relatorio_classificacao.csv", index=True
    )

    cm = confusion_matrix(y_test, best_predictions, labels=[0, 1])
    pd.DataFrame(
        cm,
        index=["Real_Nao_Satisfeito", "Real_Satisfeito"],
        columns=["Pred_Nao_Satisfeito", "Pred_Satisfeito"],
    ).to_csv(output_dir / "metrics" / "matriz_confusao.csv")

    # Importancia por permutacao no conjunto de teste. E uma analise exploratoria,
    # pois poucos registros tornam a estimativa instavel.
    perm = permutation_importance(
        best_model,
        X_test,
        y_test,
        scoring="f1_macro",
        n_repeats=30,
        random_state=RANDOM_STATE,
        n_jobs=1,
    )
    importance = pd.DataFrame(
        {
            "variavel": FEATURES,
            "importancia_media_f1_macro": perm.importances_mean,
            "desvio_padrao": perm.importances_std,
        }
    ).sort_values("importancia_media_f1_macro", ascending=False)
    importance.to_csv(output_dir / "metrics" / "importancia_permutacao.csv", index=False)

    # Figura de distribuicao do target.
    class_counts = y.map(CLASS_NAMES).value_counts().reindex(
        [CLASS_NAMES[0], CLASS_NAMES[1]], fill_value=0
    )
    fig, ax = plt.subplots(figsize=(7, 4))
    class_counts.plot(kind="bar", ax=ax)
    ax.set_title("Distribuicao da satisfacao derivada da nota")
    ax.set_xlabel("Classe")
    ax.set_ylabel("Quantidade de respostas")
    ax.tick_params(axis="x", rotation=0)
    fig.tight_layout()
    fig.savefig(output_dir / "figures" / "distribuicao_classes.png", dpi=180)
    plt.close(fig)

    # Comparacao do F1-macro no conjunto de teste.
    plot_df = comparison_df.sort_values("f1_macro", ascending=True)
    fig, ax = plt.subplots(figsize=(8, 4.8))
    ax.barh(plot_df["modelo"], plot_df["f1_macro"])
    ax.set_xlim(0, 1)
    ax.set_xlabel("F1-macro no conjunto de teste")
    ax.set_title("Comparacao dos classificadores")
    for index, value in enumerate(plot_df["f1_macro"]):
        ax.text(min(value + 0.015, 0.95), index, f"{value:.3f}", va="center")
    fig.tight_layout()
    fig.savefig(output_dir / "figures" / "comparacao_f1_macro.png", dpi=180)
    plt.close(fig)

    # Matriz de confusao.
    fig, ax = plt.subplots(figsize=(5.5, 4.5))
    disp = ConfusionMatrixDisplay(cm, display_labels=[CLASS_NAMES[0], CLASS_NAMES[1]])
    disp.plot(ax=ax, cmap="Blues", colorbar=False, values_format="d")
    ax.set_title(f"Matriz de confusao - {best_name}")
    fig.tight_layout()
    fig.savefig(output_dir / "figures" / "matriz_confusao.png", dpi=180)
    plt.close(fig)

    # Curva ROC do melhor classificador.
    fig, ax = plt.subplots(figsize=(6, 5))
    RocCurveDisplay.from_estimator(best_model, X_test, y_test, ax=ax)
    ax.plot([0, 1], [0, 1], linestyle="--", label="Acaso")
    ax.set_title(f"Curva ROC - {best_name}")
    fig.tight_layout()
    fig.savefig(output_dir / "figures" / "curva_roc.png", dpi=180)
    plt.close(fig)

    # Importancia por permutacao.
    top_importance = importance.head(7).sort_values("importancia_media_f1_macro")
    fig, ax = plt.subplots(figsize=(8, 5))
    ax.barh(top_importance["variavel"], top_importance["importancia_media_f1_macro"])
    ax.set_xlabel("Reducao media do F1-macro ao embaralhar a variavel")
    ax.set_title("Importancia por permutacao - conjunto de teste")
    fig.tight_layout()
    fig.savefig(output_dir / "figures" / "importancia_permutacao.png", dpi=180)
    plt.close(fig)

    quality.update(
        {
            "linhas_treino": int(len(X_train)),
            "linhas_teste": int(len(X_test)),
            "proporcao_teste": 0.20,
            "random_state": RANDOM_STATE,
            "validacao_cruzada": "StratifiedKFold com 5 partes, embaralhamento e random_state=42, aplicada somente ao treino",
            "criterio_busca": "F1-macro",
            "modelo_selecionado_para_artefato": best_name,
            "artefato_reajustado_apos_avaliacao": True,
            "registros_usados_no_artefato_final": int(len(X)),
        }
    )
    with (output_dir / "metrics" / "auditoria_dados.json").open("w", encoding="utf-8") as file:
        json.dump(quality, file, ensure_ascii=False, indent=2)

    comparison_records = (
        comparison_df.astype(object)
        .where(pd.notna(comparison_df), None)
        .to_dict(orient="records")
    )
    try:
        model_path_report = model_path.resolve().relative_to(Path.cwd().resolve()).as_posix()
    except ValueError:
        model_path_report = str(model_path.resolve())
    try:
        output_dir_report = output_dir.resolve().relative_to(Path.cwd().resolve()).as_posix()
    except ValueError:
        output_dir_report = str(output_dir.resolve())

    summary = {
        "dataset_rows": int(len(X)),
        "train_rows": int(len(X_train)),
        "test_rows": int(len(X_test)),
        "positive_class_name": CLASS_NAMES[1],
        "selected_model": best_name,
        "selected_metrics": best_metrics,
        "artifact_training_rows": int(len(X)),
        "artifact_training_scope": "Todos os registros, somente apos a avaliacao independente",
        "model_comparison": comparison_records,
        "quality": quality,
        "model_path": model_path_report,
        "output_dir": output_dir_report,
    }
    with (output_dir / "metrics" / "resumo_execucao.json").open("w", encoding="utf-8") as file:
        json.dump(summary, file, ensure_ascii=False, indent=2, default=str, allow_nan=False)

    return summary
