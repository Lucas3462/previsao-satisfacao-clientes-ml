"""Executor principal da etapa N2.

Integrantes: Alan Ribeiro do Carmo (RA 10428496), Jean Pazzini Domingues
(RA 10428555) e Wendell Rodrigues da Costa (RA 10420319).
E-mails institucionais dos alunos: [CONFIRMAR E INSERIR OS TRES ENDERECOS].
Docente: Prof. Dr. Leandro Zerbinatti.
Sintese: treina e compara modelos para previsao da satisfacao dos clientes.
Historico:
- 2026-11-12 | Assistencia de IA (versao de apoio) | Criacao do executor N2;
  revisar e validar pelos integrantes antes da entrega.
"""
from __future__ import annotations

import argparse
from pathlib import Path

from n2_entrega.src.modeling import run_experiment

ROOT = Path(__file__).resolve().parent


def main() -> None:
    parser = argparse.ArgumentParser(description="Executa a modelagem e avaliacao N2.")
    parser.add_argument(
        "--data",
        type=Path,
        default=ROOT / "data" / "raw" / "dataset_satisfacao_atendimento.csv",
        help="Caminho do CSV de respostas.",
    )
    parser.add_argument(
        "--output",
        type=Path,
        default=ROOT / "n2_entrega" / "results",
        help="Diretorio onde os resultados serao gravados.",
    )
    args = parser.parse_args()

    summary = run_experiment(args.data, args.output)
    print("\nEXECUCAO N2 CONCLUIDA")
    print(f"Registros: {summary['dataset_rows']} | treino: {summary['train_rows']} | teste: {summary['test_rows']}")
    print(f"Modelo selecionado: {summary['selected_model']}")
    print("Metricas no teste:")
    for metric, value in summary["selected_metrics"].items():
        print(f"  {metric}: {value:.4f}")
    print(f"Resultados: {args.output.resolve()}")


if __name__ == "__main__":
    main()
