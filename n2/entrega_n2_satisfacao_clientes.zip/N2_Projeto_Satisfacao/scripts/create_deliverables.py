"""Gera o relatorio academico e o roteiro de video da entrega N2.

Integrantes: Alan Ribeiro do Carmo (RA 10428496), Jean Pazzini Domingues
(RA 10428555) e Wendell Rodrigues da Costa (RA 10420319).
E-mails institucionais dos alunos: [CONFIRMAR E INSERIR OS TRES ENDERECOS].
Historico: 2026-11-12 | Assistencia de IA (versao de apoio) | Geracao automatizada dos documentos.
"""
from pathlib import Path
import json
from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
from docx.shared import Inches, Pt, Cm, RGBColor
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.enum.section import WD_SECTION

ROOT = Path(__file__).resolve().parents[1]
RESULTS = ROOT / "n2_entrega" / "results"
DOCS = ROOT / "docs"
DOCS.mkdir(exist_ok=True)


def set_cell_shading(cell, fill):
    tc_pr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:fill"), fill)
    tc_pr.append(shd)


def set_cell_border(cell, **kwargs):
    tc = cell._tc
    tc_pr = tc.get_or_add_tcPr()
    borders = tc_pr.first_child_found_in("w:tcBorders")
    if borders is None:
        borders = OxmlElement("w:tcBorders")
        tc_pr.append(borders)
    for edge in ("top", "left", "bottom", "right", "insideH", "insideV"):
        if edge in kwargs:
            tag = "w:" + edge
            element = borders.find(qn(tag))
            if element is None:
                element = OxmlElement(tag)
                borders.append(element)
            for key in ["val", "sz", "space", "color"]:
                if key in kwargs[edge]:
                    element.set(qn("w:" + key), str(kwargs[edge][key]))


def set_repeat_table_header(row):
    tr_pr = row._tr.get_or_add_trPr()
    tbl_header = OxmlElement("w:tblHeader")
    tbl_header.set(qn("w:val"), "true")
    tr_pr.append(tbl_header)


def set_run_font(run, name="Times New Roman", size=10.5, bold=None, italic=None, color=None):
    run.font.name = name
    run._element.rPr.rFonts.set(qn("w:eastAsia"), name)
    run.font.size = Pt(size)
    if bold is not None:
        run.bold = bold
    if italic is not None:
        run.italic = italic
    if color:
        run.font.color.rgb = RGBColor(*color)


def add_page_number(paragraph):
    paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = paragraph.add_run("Página ")
    set_run_font(r, size=8)
    fld = OxmlElement("w:fldSimple")
    fld.set(qn("w:instr"), "PAGE")
    paragraph._p.append(fld)


def setup_doc(title):
    doc = Document()
    sec = doc.sections[0]
    sec.page_width = Cm(21.0)
    sec.page_height = Cm(29.7)
    sec.top_margin = Cm(2.4)
    sec.bottom_margin = Cm(2.0)
    sec.left_margin = Cm(2.5)
    sec.right_margin = Cm(2.0)

    normal = doc.styles["Normal"]
    normal.font.name = "Times New Roman"
    normal._element.rPr.rFonts.set(qn("w:eastAsia"), "Times New Roman")
    normal.font.size = Pt(10.5)
    normal.paragraph_format.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
    normal.paragraph_format.line_spacing = 1.15
    normal.paragraph_format.space_after = Pt(5)
    normal.paragraph_format.first_line_indent = Cm(1.25)

    for style_name, size in [("Heading 1", 13), ("Heading 2", 11.5), ("Heading 3", 10.5)]:
        st = doc.styles[style_name]
        st.font.name = "Times New Roman"
        st._element.rPr.rFonts.set(qn("w:eastAsia"), "Times New Roman")
        st.font.size = Pt(size)
        st.font.bold = True
        st.font.color.rgb = RGBColor(0, 0, 0)
        st.paragraph_format.keep_with_next = True
        st.paragraph_format.space_before = Pt(10 if style_name == "Heading 1" else 7)
        st.paragraph_format.space_after = Pt(4)
        st.paragraph_format.first_line_indent = Cm(0)

    header = sec.header.paragraphs[0]
    header.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    rr = header.add_run("UNIVERSIDADE PRESBITERIANA MACKENZIE | FCI | INTELIGÊNCIA ARTIFICIAL")
    set_run_font(rr, size=7.5, color=(90, 90, 90))
    footer = sec.footer.paragraphs[0]
    add_page_number(footer)
    doc.core_properties.title = title
    doc.core_properties.subject = "Projeto de Inteligência Artificial - N2"
    doc.core_properties.author = "Alan Ribeiro do Carmo; Jean Pazzini Domingues; Wendell Rodrigues da Costa"
    return doc


def add_body(doc, text, first_indent=True, align=WD_ALIGN_PARAGRAPH.JUSTIFY, bold_prefix=None):
    p = doc.add_paragraph()
    p.alignment = align
    p.paragraph_format.line_spacing = 1.15
    p.paragraph_format.space_after = Pt(5)
    p.paragraph_format.first_line_indent = Cm(1.25) if first_indent else Cm(0)
    p.paragraph_format.keep_together = True
    if bold_prefix and text.startswith(bold_prefix):
        r = p.add_run(bold_prefix)
        set_run_font(r, bold=True)
        r2 = p.add_run(text[len(bold_prefix):])
        set_run_font(r2)
    else:
        r = p.add_run(text)
        set_run_font(r)
    return p


def add_heading(doc, text, level=1):
    p = doc.add_heading(text, level=level)
    p.paragraph_format.keep_with_next = True
    return p


def add_caption(doc, text):
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.first_line_indent = Cm(0)
    p.paragraph_format.space_before = Pt(3)
    p.paragraph_format.space_after = Pt(8)
    p.paragraph_format.keep_together = True
    r = p.add_run(text)
    set_run_font(r, size=8.5, italic=True)
    return p


def add_figure(doc, path, width, caption):
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.first_line_indent = Cm(0)
    p.paragraph_format.space_before = Pt(3)
    p.paragraph_format.space_after = Pt(0)
    p.paragraph_format.keep_with_next = True
    p.add_run().add_picture(str(path), width=Inches(width))
    add_caption(doc, caption)


def add_table(doc, headers, rows, widths=None, font_size=8.3):
    table = doc.add_table(rows=1, cols=len(headers))
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.style = "Table Grid"
    table.autofit = False
    header = table.rows[0]
    set_repeat_table_header(header)
    for i, label in enumerate(headers):
        cell = header.cells[i]
        cell.text = str(label)
        cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
        set_cell_shading(cell, "D9E2F3")
        for p in cell.paragraphs:
            p.alignment = WD_ALIGN_PARAGRAPH.CENTER
            p.paragraph_format.first_line_indent = Cm(0)
            p.paragraph_format.space_after = Pt(1)
            for run in p.runs:
                set_run_font(run, size=font_size, bold=True)
    for row_values in rows:
        cells = table.add_row().cells
        for i, value in enumerate(row_values):
            cells[i].text = str(value)
            cells[i].vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
            for p in cells[i].paragraphs:
                p.alignment = WD_ALIGN_PARAGRAPH.CENTER if i else WD_ALIGN_PARAGRAPH.LEFT
                p.paragraph_format.first_line_indent = Cm(0)
                p.paragraph_format.space_after = Pt(1)
                for run in p.runs:
                    set_run_font(run, size=font_size)
    if widths:
        for row in table.rows:
            for i, width in enumerate(widths):
                row.cells[i].width = Inches(width)
    doc.add_paragraph().paragraph_format.space_after = Pt(0)
    return table


def add_bullet(doc, text):
    p = doc.add_paragraph(style="List Bullet")
    p.paragraph_format.left_indent = Cm(0.8)
    p.paragraph_format.first_line_indent = Cm(0)
    p.paragraph_format.space_after = Pt(2)
    p.paragraph_format.keep_together = True
    r = p.add_run(text)
    set_run_font(r)
    return p


# ---------------------- RELATORIO ----------------------
title = "Predição da satisfação de clientes a partir de características do atendimento utilizando Machine Learning"
doc = setup_doc(title)

p = doc.add_paragraph()
p.alignment = WD_ALIGN_PARAGRAPH.CENTER
p.paragraph_format.space_before = Pt(14)
p.paragraph_format.space_after = Pt(14)
r = p.add_run(title)
set_run_font(r, size=14, bold=True)

for text in [
    "Alan Ribeiro do Carmo (RA 10428496)¹; Jean Pazzini Domingues (RA 10428555)¹; Wendell Rodrigues da Costa (RA 10420319)¹",
    "Prof. Dr. Leandro Zerbinatti²",
]:
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.first_line_indent = Cm(0)
    p.paragraph_format.space_after = Pt(3)
    r = p.add_run(text)
    set_run_font(r, size=9.5, bold=("¹" in text))

for text in [
    "¹ Faculdade de Computação e Informática (FCI), Universidade Presbiteriana Mackenzie — São Paulo, SP — Brasil",
    "² Docente da disciplina Inteligência Artificial — Sistemas de Informação — 7ºJ — Noturno",
    "E-mails institucionais dos alunos: [CONFIRMAR E INSERIR OS TRÊS ENDEREÇOS]",
    "leandro.zerbinatti@mackenzie.br",
    "2026",
]:
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.first_line_indent = Cm(0)
    p.paragraph_format.space_after = Pt(2)
    p.paragraph_format.keep_together = True
    r = p.add_run(text)
    set_run_font(r, size=8.5)

add_heading(doc, "Resumo", 1)
abstract_pt = (
    "Este projeto desenvolve uma solução de classificação supervisionada para estimar a satisfação de clientes a partir de características do atendimento. A base, coletada por questionário e anonimizada conforme a documentação do grupo, contém 207 respostas e 11 colunas. Na auditoria, não foram observados valores ausentes, linhas duplicadas ou identificadores repetidos; foram, contudo, identificadas 31 divergências entre o rótulo de satisfação fornecido no arquivo e a regra definida para a nota do atendimento. Por esse motivo, o alvo foi derivado diretamente da nota: valores de 1 a 3 representam “Não satisfeito” e valores 4 ou 5 representam “Satisfeito”. Foram utilizadas sete características do atendimento, excluindo o identificador, a nota que origina o alvo, o rótulo original e a intenção de recompra. A metodologia comparou regressão logística, árvore de decisão e Random Forest com um baseline majoritário. Os dados foram separados em treino e teste, com estratificação, e a seleção de hiperparâmetros foi realizada por validação cruzada estratificada de cinco partes, usando F1-macro. O Random Forest obteve o maior F1-macro médio na validação cruzada (0,754) e foi selecionado. No teste, alcançou acurácia de 76,2%, acurácia balanceada de 76,8%, F1-macro de 70,8% e ROC-AUC de 91,9%. Os resultados demonstram viabilidade experimental, mas também evidenciam limitações relacionadas ao tamanho e ao desequilíbrio da amostra, exigindo validação adicional antes de qualquer uso operacional."
)
add_body(doc, abstract_pt, first_indent=False)
add_body(doc, "Palavras-chave: satisfação de clientes; aprendizado de máquina; classificação supervisionada; atendimento ao cliente.", first_indent=False)

add_heading(doc, "Abstract", 1)
abstract_en = (
    "This project develops a supervised classification solution to estimate customer satisfaction from customer-service characteristics. The dataset, collected through a questionnaire and anonymized according to the group's documentation, contains 207 responses and 11 columns. The data audit found no missing values, duplicated rows, or repeated identifiers; however, 31 discrepancies were identified between the satisfaction label provided in the file and the rule defined from the service rating. Therefore, the target was derived directly from the rating: values from 1 to 3 represent “Not satisfied”, while values 4 or 5 represent “Satisfied”. Seven service-related features were used, excluding the response identifier, the rating used to derive the target, the original label, and repurchase intention. The methodology compared logistic regression, decision tree, and Random Forest models against a majority-class baseline. The dataset was split into stratified training and test sets, and hyperparameter selection was performed through five-fold stratified cross-validation using macro F1. Random Forest achieved the highest mean macro F1 in cross-validation (0.754) and was selected. On the test set, it reached 76.2% accuracy, 76.8% balanced accuracy, 70.8% macro F1, and 91.9% ROC-AUC. The results demonstrate experimental feasibility but also highlight limitations related to sample size and class imbalance, requiring further validation before any operational use."
)
add_body(doc, abstract_en, first_indent=False)
add_body(doc, "Keywords: customer satisfaction; machine learning; supervised classification; customer service.", first_indent=False)

add_heading(doc, "1. Introdução", 1)
add_heading(doc, "1.1 Contextualização", 2)
add_body(doc, "A satisfação de clientes é um indicador relevante para avaliar a experiência oferecida durante o atendimento. Elementos como canal de contato, tempo de espera, resolução do problema, necessidade de contato adicional, cordialidade e facilidade percebida podem estar associados à avaliação registrada pelo consumidor. Em operações de atendimento, a identificação de padrões nesses dados pode apoiar análises sobre a experiência e ajudar equipes a investigar situações que mereçam atenção.")
add_body(doc, "Técnicas de aprendizado de máquina permitem construir classificadores a partir de exemplos rotulados. Em classificação supervisionada, o algoritmo recebe observações com atributos e classes conhecidas e aprende uma função capaz de estimar a classe de novos registros. Bibliotecas como scikit-learn oferecem componentes para preparação, treinamento, validação e avaliação desses modelos (PEDREGOSA et al., 2011).")

add_heading(doc, "1.2 Justificativa", 2)
add_body(doc, "No N1, o grupo realizou a proposta, a análise exploratória e a preparação inicial da base. A etapa N2 é necessária para verificar se as variáveis documentadas oferecem informação preditiva sobre a classe de satisfação e para comparar algoritmos sob um procedimento de avaliação reproduzível. A escolha de métricas além da acurácia é importante porque a distribuição das classes é desigual: há mais respostas classificadas como satisfeitas do que como não satisfeitas. Em conjuntos desbalanceados, a acurácia isolada pode ocultar o desempenho insuficiente na classe minoritária (HE; GARCIA, 2009).")

add_heading(doc, "1.3 Objetivo", 2)
add_body(doc, "Desenvolver e avaliar modelos de classificação supervisionada capazes de estimar a satisfação de clientes a partir de características relacionadas ao atendimento, utilizando a base coletada pelo grupo.")
add_body(doc, "Como objetivos específicos, foram definidos: (i) auditar e validar o conjunto de dados; (ii) derivar o alvo de acordo com a regra definida no N1; (iii) preparar variáveis numéricas e categóricas sem utilizar informações que revelem diretamente a classe; (iv) treinar e comparar regressão logística, árvore de decisão e Random Forest; (v) avaliar os modelos com métricas adequadas ao desequilíbrio de classes; e (vi) disponibilizar um artefato demonstrativo de previsão e os arquivos necessários à reprodução.")

add_heading(doc, "1.4 Opção do projeto", 2)
add_body(doc, "O projeto segue a Opção Framework prevista no enunciado da disciplina, utilizando Python e scikit-learn para uma tarefa de classificação supervisionada.")

add_heading(doc, "1.5 Descrição do problema", 2)
add_body(doc, "O problema investigado é: em que medida características do atendimento permitem estimar se uma resposta será classificada como satisfeita ou não satisfeita? A variável-alvo é binária e deriva da coluna Nota_para_o_atendimento_1_a_5: notas 1, 2 ou 3 recebem classe 0 (Nao-Satisfeito), enquanto notas 4 ou 5 recebem classe 1 (Satisfeito). A coluna Satisfacao existente no CSV não foi utilizada como alvo de treinamento porque a auditoria do N1 identificou divergências em relação a essa regra.")

add_heading(doc, "1.6 Aspectos éticos e responsabilidade", 2)
add_body(doc, "O arquivo analisado não contém nomes ou identificadores pessoais diretos, e o campo ID_Resposta é utilizado apenas para auditoria, não como variável de entrada. Ainda assim, a anonimização não elimina todos os riscos: a faixa etária é uma característica demográfica e pode contribuir para padrões discriminatórios se for utilizada sem avaliação crítica. Além disso, a amostra é pequena, pode refletir viés de seleção e não representa necessariamente toda a população de clientes.")
add_body(doc, "O modelo é experimental e acadêmico. Suas saídas não devem ser utilizadas para negar atendimento, priorizar ou penalizar pessoas, nem substituir a avaliação humana. Uma eventual aplicação real exigiria autorização e governança sobre os dados, transparência sobre a finalidade, controles de acesso, avaliação de vieses por grupos, monitoramento de mudanças no perfil dos dados e validação em amostra externa. As relações encontradas são associativas e preditivas; não demonstram que uma variável cause satisfação ou insatisfação.")

add_heading(doc, "2. Referencial teórico", 1)
add_heading(doc, "2.1 Classificação supervisionada", 2)
add_body(doc, "A classificação supervisionada é uma tarefa de aprendizado na qual o modelo aprende a relacionar atributos de entrada a uma classe previamente definida. O procedimento envolve a preparação dos dados, a divisão entre treino e teste, o ajuste dos parâmetros do modelo e a avaliação em observações não utilizadas no treinamento. A implementação foi realizada com scikit-learn, que fornece estimadores, transformadores e pipelines para organizar essas etapas de maneira reproduzível (PEDREGOSA et al., 2011).")
add_heading(doc, "2.2 Algoritmos comparados", 2)
add_body(doc, "A regressão logística estima a probabilidade de uma observação pertencer a uma classe e constitui uma referência clássica para problemas binários. A árvore de decisão produz regras hierárquicas de divisão dos atributos e oferece uma representação interpretável, embora possa apresentar instabilidade quando a amostra é pequena. O Random Forest combina múltiplas árvores treinadas com amostras e subconjuntos aleatórios de atributos, buscando reduzir a variância de uma árvore individual (BREIMAN, 2001).")
add_heading(doc, "2.3 Avaliação e desequilíbrio entre classes", 2)
add_body(doc, "A acurácia representa a proporção total de previsões corretas. Precisão mede a proporção de previsões positivas que estão corretas, enquanto revocação (recall) mede a proporção dos positivos reais identificados. O F1 combina precisão e revocação por média harmônica; o F1-macro calcula o F1 de cada classe e atribui o mesmo peso às classes. A acurácia balanceada calcula a média da revocação por classe. A curva ROC e sua área (ROC-AUC) avaliam a capacidade de ordenar exemplos positivos acima dos negativos em diferentes limiares (FAWCETT, 2006).")
add_body(doc, "Essas métricas são relevantes neste projeto porque 78,7% dos registros pertencem à classe Satisfeito. Um classificador que escolha sempre a classe majoritária pode obter acurácia aparentemente alta sem identificar os registros não satisfeitos. A análise conjunta de F1-macro, acurácia balanceada, precisão, recall e ROC-AUC permite uma leitura mais equilibrada dos erros (HE; GARCIA, 2009).")

add_heading(doc, "3. Metodologia", 1)
add_heading(doc, "3.1 Tipo de pesquisa e ambiente", 2)
add_body(doc, "Trata-se de um estudo aplicado, quantitativo e experimental, com desenvolvimento e comparação de modelos de classificação. A implementação foi realizada em Python, utilizando pandas, NumPy, Matplotlib e scikit-learn. Os pipelines de preparação e classificação são mantidos juntos para que os transformadores sejam ajustados somente nos dados de treino de cada partição.")
add_heading(doc, "3.2 Dataset e auditoria", 2)
add_body(doc, "A base dataset_satisfacao_atendimento.csv foi coletada pelo grupo por meio de questionário, conforme descrito no material do N1. Contém 207 respostas e 11 colunas. A auditoria reproduzida na N2 encontrou zero valores ausentes, zero linhas duplicadas, zero IDs duplicados e zero notas fora do intervalo de 1 a 5.")
add_body(doc, "Foram identificadas 31 divergências entre a coluna original Satisfacao e a regra oficial baseada na nota: 28 registros com nota 4 rotulados originalmente como Nao-Satisfeito, dois registros com nota 5 rotulados como Nao-Satisfeito e um registro com nota 3 rotulado como Satisfeito. Por isso, a coluna bruta foi preservada sem alteração e o alvo foi recalculado em memória pela regra documentada.")
add_body(doc, "A distribuição resultante foi de 44 observações Nao-Satisfeito (21,3%) e 163 observações Satisfeito (78,7%). A presença dessa assimetria foi considerada durante a escolha das métricas e na análise do baseline.")
add_figure(doc, RESULTS / "figures" / "distribuicao_classes.png", 5.4, "Figura 1. Distribuição da classe-alvo derivada da nota de atendimento. Fonte: dados do projeto (2026).")

add_heading(doc, "3.3 Variáveis utilizadas e prevenção de vazamento", 2)
add_body(doc, "Foram utilizadas sete features: Faixa_etaria, Canal_de_atendimento, Tempo_de_espera_minutos, Problema_foi_resolvido, Precisou_contato_novamente, Atendimento_foi_cordial e Facilidade_para_resolver_1_a_5.")
add_body(doc, "Foram excluídas ID_Resposta, por ser identificador técnico; Nota_para_o_atendimento_1_a_5, por originar diretamente a classe; Satisfacao, por conter inconsistências auditadas; e Voltaria_a_comprar, por representar uma possível consequência da experiência e não uma característica de atendimento apropriada para a previsão pretendida. Essa separação evita que o modelo receba diretamente o valor usado para construir o target ou informações que possam revelar o resultado.")
add_body(doc, "As variáveis categóricas foram codificadas com One-Hot Encoding, permitindo que o modelo trabalhe com categorias sem impor uma ordem artificial. O pipeline prevê imputação numérica pela mediana e categórica pela categoria mais frequente, além de padronização das variáveis numéricas. Como a auditoria não encontrou valores ausentes nesta base, não foi necessária imputação efetiva. As transformações foram implementadas em ColumnTransformer dentro de Pipeline, evitando que estatísticas do conjunto de teste contaminem o treinamento.")

add_heading(doc, "3.4 Treinamento e validação", 2)
add_body(doc, "A base foi dividida em 80% para treino (165 registros) e 20% para teste (42 registros), utilizando estratificação e random_state=42. No conjunto de treino, os hiperparâmetros foram pesquisados com GridSearchCV e StratifiedKFold de cinco partes, com embaralhamento. O critério de seleção foi F1-macro.")
add_body(doc, "Foram comparados: (i) um baseline DummyClassifier que sempre prevê a classe majoritária; (ii) regressão logística; (iii) árvore de decisão; e (iv) Random Forest. As grades de hiperparâmetros e as melhores configurações são registradas em n2_entrega/results/metrics/comparacao_modelos.csv. O modelo final salvo foi escolhido pelo maior F1-macro médio na validação cruzada do treino. O conjunto de teste foi reservado para a avaliação final e não participou da seleção dos hiperparâmetros.")

add_heading(doc, "3.5 Métricas", 2)
add_body(doc, "Foram calculadas acurácia, acurácia balanceada, precisão, recall e F1 para a classe positiva (Satisfeito), F1-macro e ROC-AUC. Também foram salvas a matriz de confusão, o relatório por classe e a importância por permutação. A última análise é tratada como exploratória, pois o conjunto de teste contém apenas 42 observações.")

add_heading(doc, "4. Resultados e discussão", 1)
add_heading(doc, "4.1 Comparação dos modelos", 2)
add_body(doc, "A Tabela 1 apresenta a média de F1-macro obtida na validação cruzada do treino e as métricas medidas no conjunto de teste. Os valores são apresentados como proporções entre 0 e 1.")
add_caption(doc, "Tabela 1. Comparação da validação cruzada e do conjunto de teste.")
add_table(doc,
    ["Modelo", "F1-macro CV", "Acurácia", "Acc. balanceada", "F1-macro teste", "ROC-AUC"],
    [
        ["Random Forest", "0,7538", "0,7619", "0,7677", "0,7083", "0,9192"],
        ["Regressão Logística", "0,7261", "0,9286", "0,8737", "0,8894", "0,9226"],
        ["Árvore de Decisão", "0,6994", "0,9048", "0,8586", "0,8586", "0,8889"],
        ["Baseline majoritário", "—", "0,7857", "0,5000", "0,4400", "0,5000"],
    ],
    widths=[1.45, 0.83, 0.78, 1.08, 1.0, 0.7], font_size=7.7
)
add_caption(doc, "Fonte: resultados da execução reproduzível do projeto (2026).")
add_figure(doc, RESULTS / "figures" / "comparacao_f1_macro.png", 5.8, "Figura 2. F1-macro de teste dos classificadores. A seleção do artefato final foi feita pela validação cruzada no treino. Fonte: dados do projeto (2026).")
add_body(doc, "O Random Forest obteve a maior média de F1-macro na validação cruzada do conjunto de treino (0,7538) e foi selecionado para compor o artefato de previsão. No conjunto de teste, entretanto, a regressão logística apresentou as melhores métricas pontuais (acurácia de 92,9% e F1-macro de 0,8894), seguida pela árvore de decisão. O Random Forest atingiu F1-macro de 0,7083. Essa diferença entre validação cruzada e teste mostra a variabilidade esperada em uma amostra pequena: não se deve interpretar a escolha do Random Forest como evidência de superioridade geral. A decisão de seleção foi mantida conforme o critério predefinido de validação cruzada, sem escolher o algoritmo retrospectivamente pelo resultado do teste.")
add_body(doc, "O baseline majoritário obteve acurácia de 78,6%, maior que os 76,2% do Random Forest, mas sua acurácia balanceada foi 0,50 e seu F1-macro 0,44. Isso ocorre porque o baseline sempre prevê a classe Satisfeito e não identifica a classe minoritária. O Random Forest reduz esse problema, alcançando acurácia balanceada de 0,7677 e F1-macro de 0,7083. Portanto, a acurácia isolada não seria suficiente para comparar os modelos.")

add_heading(doc, "4.2 Avaliação do modelo selecionado", 2)
add_body(doc, "O Random Forest selecionado utiliza 200 árvores, max_depth=None, min_samples_leaf=4 e class_weight=balanced_subsample. No conjunto de teste, apresentou acurácia de 0,7619, acurácia balanceada de 0,7677, precisão para a classe Satisfeito de 0,9259, recall de 0,7576, F1 da classe positiva de 0,8333, F1-macro de 0,7083 e ROC-AUC de 0,9192.")
add_caption(doc, "Tabela 2. Matriz de confusão do Random Forest no conjunto de teste.")
add_table(doc,
    ["Classe real", "Predito: não satisfeito", "Predito: satisfeito"],
    [["Não satisfeito", "7", "2"], ["Satisfeito", "8", "25"]],
    widths=[1.6, 1.7, 1.7], font_size=8.5
)
add_figure(doc, RESULTS / "figures" / "matriz_confusao.png", 4.4, "Figura 3. Matriz de confusão do Random Forest. Fonte: dados do projeto (2026).")
add_figure(doc, RESULTS / "figures" / "curva_roc.png", 4.6, "Figura 4. Curva ROC do Random Forest (AUC = 0,9192). Fonte: dados do projeto (2026).")
add_body(doc, "A matriz de confusão registrou sete não satisfeitos corretamente identificados, dois não satisfeitos previstos como satisfeitos, oito satisfeitos previstos como não satisfeitos e 25 satisfeitos corretamente identificados. Em termos práticos, o modelo reconheceu 7 dos 9 registros não satisfeitos no teste e 25 dos 33 registros satisfeitos. O número reduzido de casos em cada classe no teste exige cautela ao interpretar essas proporções.")

add_heading(doc, "4.3 Importância por permutação", 2)
add_body(doc, "A análise de importância por permutação apresentou uma pequena importância média positiva para Precisou_contato_novamente (+0,0286 em F1-macro). As demais variáveis tiveram valores médios negativos nesta execução. Isso não significa que tenham efeito causal negativo: indica apenas que, ao embaralhá-las neste conjunto de teste pequeno e nesta execução, não foi observada melhora do F1-macro. A instabilidade e a baixa quantidade de observações impedem conclusões firmes sobre a contribuição individual das variáveis.")
add_figure(doc, RESULTS / "figures" / "importancia_permutacao.png", 5.6, "Figura 5. Importância por permutação no conjunto de teste. Valores negativos não representam efeito causal. Fonte: dados do projeto (2026).")

add_heading(doc, "4.4 Artefato demonstrativo", 2)
add_body(doc, "Após a avaliação independente no conjunto de teste, uma cópia do pipeline selecionado foi reajustada com os 207 registros e serializada em n2_entrega/results/models/modelo_satisfacao.joblib. As métricas deste relatório continuam sendo as obtidas antes desse reajuste: o modelo foi ajustado em 165 registros e avaliado nos 42 registros reservados. O projeto disponibiliza demonstração por terminal (python n2_entrega/predict.py) e interface Streamlit (streamlit run n2_entrega/app_streamlit.py). A interface recebe as sete características e exibe a classe estimada e a probabilidade estimada de pertencer à classe Satisfeito. A probabilidade é uma saída do modelo, não uma certeza sobre a opinião do cliente.")

add_heading(doc, "4.5 Limitações", 2)
add_body(doc, "As principais limitações são: (i) amostra pequena, com somente 207 respostas; (ii) desequilíbrio entre classes; (iii) possível viés de seleção decorrente do processo de coleta por questionário; (iv) ausência de validação externa em uma segunda coleta independente; (v) instabilidade das métricas e da importância das variáveis em partições pequenas; e (vi) ausência de informação suficiente no material disponibilizado para caracterizar detalhadamente a população de origem e o contexto empresarial da coleta. Os resultados devem ser considerados experimentais e não generalizados para outras empresas ou públicos.")

add_heading(doc, "5. Conclusão", 1)
add_body(doc, "O projeto desenvolveu uma solução de classificação supervisionada para estimar a satisfação de clientes com base em características do atendimento. O conjunto de dados foi auditado, o alvo foi derivado pela regra definida no N1 e foram comparados um baseline majoritário, regressão logística, árvore de decisão e Random Forest. O processo utilizou divisão estratificada entre treino e teste, validação cruzada no treino e métricas que consideram o desequilíbrio de classes.")
add_body(doc, "O Random Forest apresentou a maior média de F1-macro na validação cruzada (0,7538) e foi selecionado para a demonstração. No teste, alcançou F1-macro de 0,7083, acurácia balanceada de 0,7677 e ROC-AUC de 0,9192. Embora a regressão logística tenha apresentado resultado pontual superior no conjunto de teste, a seleção foi mantida pelo critério de validação cruzada previamente estabelecido. O baseline mostrou por que a acurácia isolada não é adequada para este cenário: mesmo com acurácia de 78,6%, não reconheceu a classe minoritária.")
add_body(doc, "Assim, o objetivo foi alcançado em caráter experimental: foram implementados e avaliados classificadores e foi disponibilizado um artefato demonstrativo. Entretanto, os resultados não autorizam uso operacional. Como continuidade, recomenda-se ampliar a amostra, documentar melhor a população e o contexto da coleta, executar validação externa, avaliar estabilidade por subgrupos, revisar os custos dos diferentes tipos de erro e recalibrar o modelo antes de qualquer aplicação prática.")

add_heading(doc, "6. Endereços do projeto", 1)
add_body(doc, "GitHub: https://github.com/Lucas3462/previsao-satisfacao-clientes-ml", first_indent=False)
add_body(doc, "Vídeo no YouTube: [INSERIR A URL PÚBLICA DO VÍDEO APÓS A GRAVAÇÃO E PUBLICAÇÃO]", first_indent=False)
add_body(doc, "O vídeo deve ser publicado em modo público e ter duração máxima de cinco minutos, conforme o enunciado da disciplina. O endereço deverá ser inserido nesta seção antes do envio definitivo do relatório.", first_indent=False)

add_heading(doc, "7. Referências bibliográficas", 1)
references = [
    "BREIMAN, Leo. Random forests. Machine Learning, v. 45, p. 5-32, 2001. DOI: https://doi.org/10.1023/A:1010933404324.",
    "FAWCETT, Tom. An introduction to ROC analysis. Pattern Recognition Letters, v. 27, n. 8, p. 861-874, 2006. DOI: https://doi.org/10.1016/j.patrec.2005.10.010.",
    "HE, Haibo; GARCIA, Edwardo A. Learning from imbalanced data. IEEE Transactions on Knowledge and Data Engineering, v. 21, n. 9, p. 1263-1284, 2009. DOI: https://doi.org/10.1109/TKDE.2008.239.",
    "PEDREGOSA, Fabian et al. Scikit-learn: Machine Learning in Python. Journal of Machine Learning Research, v. 12, n. 85, p. 2825-2830, 2011.",
    "RIBEIRO DO CARMO, Alan; DOMINGUES, Jean Pazzini; COSTA, Wendell Rodrigues da. Relatório do projeto de Inteligência Artificial - N1: Predição da satisfação de clientes a partir de características do atendimento utilizando Machine Learning. Universidade Presbiteriana Mackenzie, 2026. Disponível em: https://github.com/Lucas3462/previsao-satisfacao-clientes-ml.",
    "UNIVERSIDADE PRESBITERIANA MACKENZIE. Faculdade de Computação e Informática. Projeto da disciplina: Aplicação de Inteligência Artificial em Problema Real - 7ºJ SI - Noite. São Paulo, 2026. Documento fornecido pelo docente.",
]
for ref in references:
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.LEFT
    p.paragraph_format.first_line_indent = Cm(0)
    p.paragraph_format.left_indent = Cm(0)
    p.paragraph_format.left_indent = Cm(0.75)
    p.paragraph_format.first_line_indent = Cm(-0.75)
    p.paragraph_format.space_after = Pt(6)
    r = p.add_run(ref)
    set_run_font(r, size=9.2)

report_path = DOCS / "relatorio_projeto_n2.docx"
doc.save(report_path)

# ---------------------- ROTEIRO ----------------------
script = setup_doc("Roteiro de vídeo - Projeto N2")
p = script.add_paragraph()
p.alignment = WD_ALIGN_PARAGRAPH.CENTER
p.paragraph_format.space_before = Pt(18)
p.paragraph_format.space_after = Pt(12)
r = p.add_run("ROTEIRO DE VÍDEO — APRESENTAÇÃO DO PROJETO N2")
set_run_font(r, size=15, bold=True)
p = script.add_paragraph()
p.alignment = WD_ALIGN_PARAGRAPH.CENTER
p.paragraph_format.first_line_indent = Cm(0)
r = p.add_run("Previsão da satisfação de clientes utilizando Machine Learning")
set_run_font(r, size=12, bold=True)
for line in [
    "Duração planejada: aproximadamente 4min50s (limite do enunciado: 5 minutos)",
    "Integrantes: Alan Ribeiro do Carmo, Jean Pazzini Domingues e Wendell Rodrigues da Costa",
    "Professor: Prof. Dr. Leandro Zerbinatti | Disciplina: Inteligência Artificial | Sistemas de Informação — 7ºJ — Mackenzie",
]:
    p = script.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.first_line_indent = Cm(0)
    r = p.add_run(line)
    set_run_font(r, size=9)

add_heading(script, "Antes de gravar", 1)
for item in [
    "Execute o projeto na raiz: python -m pip install -r requirements.txt; depois python run_n2.py.",
    "Abra a demonstração: streamlit run n2_entrega/app_streamlit.py. Deixe a interface pronta antes de iniciar a gravação.",
    "Abra o repositório GitHub em outra aba. Tenha também o relatório e a tabela de métricas disponíveis.",
    "Gravem a tela com áudio claro. Evitem ler os parágrafos literalmente; usem o texto abaixo como guia.",
]:
    add_bullet(script, item)

segments = [
    ("0:00–0:25 | Abertura e identificação", "Tela: capa com o título do projeto e os nomes dos três integrantes.\n\nFala sugerida: “Olá! Nós somos Alan Ribeiro do Carmo, Jean Pazzini Domingues e Wendell Rodrigues da Costa, alunos de Sistemas de Informação da Universidade Presbiteriana Mackenzie. Este é o projeto da disciplina Inteligência Artificial, ministrada pelo professor Leandro Zerbinatti. Nosso trabalho é a previsão da satisfação de clientes a partir de características do atendimento, utilizando Machine Learning.”"),
    ("0:25–0:55 | Problema e objetivo", "Tela: apresentar a pergunta do projeto.\n\nFala sugerida: “O problema que investigamos é se informações sobre o atendimento, como canal utilizado, tempo de espera, resolução do problema e cordialidade, permitem estimar se um cliente ficará satisfeito ou não. Nosso objetivo foi desenvolver e avaliar modelos de classificação supervisionada para realizar essa estimativa.”"),
    ("0:55–1:30 | Dataset e preparação", "Tela: mostrar rapidamente o CSV e, em seguida, a distribuição das classes no notebook ou relatório.\n\nFala sugerida: “Utilizamos a base coletada pelo grupo por questionário, com 207 respostas anonimizadas. Na auditoria, não encontramos valores ausentes nem registros duplicados. Identificamos 31 divergências na coluna de satisfação original. Por isso, seguimos a regra documentada no N1: notas de 1 a 3 foram classificadas como não satisfeitas e notas 4 ou 5 como satisfeitas. O conjunto ficou com 44 registros não satisfeitos e 163 satisfeitos. Excluímos identificador, nota, rótulo original e intenção de recompra das variáveis de entrada para evitar vazamento de informação.”"),
    ("1:30–2:25 | Metodologia e algoritmos", "Tela: mostrar o notebook e a seção de metodologia.\n\nFala sugerida: “Utilizamos sete características do atendimento. As variáveis categóricas foram transformadas por One-Hot Encoding e as numéricas foram padronizadas, dentro de pipelines do scikit-learn. Separamos 80% dos dados para treino e 20% para teste, com estratificação. No treino, usamos validação cruzada estratificada de cinco partes e busca de hiperparâmetros com F1-macro. Comparamos um baseline majoritário, regressão logística, árvore de decisão e Random Forest. A escolha do modelo final foi feita pelo resultado médio da validação cruzada, deixando o conjunto de teste reservado para avaliação.”"),
    ("2:25–3:25 | Resultados e interpretação", "Tela: apresentar a tabela de comparação, a matriz de confusão e a curva ROC.\n\nFala sugerida: “O Random Forest obteve o maior F1-macro médio na validação cruzada, aproximadamente 0,754, e por isso foi selecionado para a demonstração. No conjunto de teste, alcançou acurácia balanceada de 0,768, F1-macro de 0,708 e ROC-AUC de 0,919. É importante destacar que a regressão logística teve resultado pontual superior nesse conjunto de teste. Mantivemos a seleção pelo critério definido antes da avaliação, baseado na validação cruzada, e isso mostra a instabilidade que pode ocorrer com uma amostra pequena. O baseline teve acurácia de 78,6%, mas não identificou a classe minoritária. Por isso, analisamos também F1-macro e acurácia balanceada, e não apenas acurácia.”"),
    ("3:25–4:20 | Demonstração do artefato", "Tela: abrir a interface Streamlit. Preencher: faixa 26-40; canal WhatsApp; espera 5 minutos; problema resolvido Sim; novo contato Não; cordialidade Sim; facilidade 4. Clicar em “Prever satisfação”.\n\nFala sugerida: “Aqui está a interface demonstrativa. Informamos características de um atendimento e o pipeline treinado retorna uma classe estimada e a probabilidade estimada de satisfação. Neste exemplo, o resultado é Satisfeito. Essa probabilidade não é uma certeza nem deve ser usada para tomar decisões automáticas sobre clientes; trata-se de uma demonstração acadêmica.”"),
    ("4:20–4:50 | GitHub e encerramento", "Tela: abrir o repositório GitHub e mostrar README, pasta n2, notebook, resultados, modelo e relatório.\n\nFala sugerida: “Todo o material do projeto está organizado no GitHub: dataset, código-fonte, notebook, métricas, gráficos, modelo treinado, interface e relatório. Concluímos que a classificação é tecnicamente viável como experimento, mas a amostra pequena e o desequilíbrio das classes exigem mais dados e validação externa antes de qualquer uso real. Obrigado!”"),
]
for heading, body in segments:
    add_heading(script, heading, 2)
    for para in body.split("\n\n"):
        add_body(script, para, first_indent=False)

add_heading(script, "Checklist de publicação", 1)
for item in [
    "Confirmar que todos os integrantes concordam com a versão final e com a apresentação dos dados.",
    "Conferir a duração total (máximo de 5 minutos) e se o vídeo mostra o funcionamento real do artefato.",
    "Publicar o vídeo em modo Público no YouTube de um dos integrantes.",
    "Copiar a URL pública do vídeo para a seção 6 do relatório e para o README do projeto.",
    "Conferir se o relatório, notebook e arquivos de código no GitHub correspondem à execução apresentada no vídeo.",
]:
    add_bullet(script, item)

script_path = DOCS / "roteiro_video_n2.docx"
script.save(script_path)
print(report_path)
print(script_path)
