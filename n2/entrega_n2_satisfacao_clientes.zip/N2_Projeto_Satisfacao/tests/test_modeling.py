"""Testes automatizados da preparacao de dados da N2.

Integrantes: Alan Ribeiro do Carmo (RA 10428496), Jean Pazzini Domingues
(RA 10428555) e Wendell Rodrigues da Costa (RA 10420319).
E-mails institucionais dos alunos: [CONFIRMAR E INSERIR OS TRES ENDERECOS].
Historico: 2026-11-12 | Assistencia de IA (versao de apoio) | Testes de validacao inicial.
"""
from pathlib import Path

import numpy as np

from n2_entrega.src.modeling import FEATURES, build_preprocessor, load_and_validate_dataset

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data" / "raw" / "dataset_satisfacao_atendimento.csv"


def test_dataset_has_207_rows_and_no_missing_values():
    X, y, quality = load_and_validate_dataset(DATA)
    assert len(X) == 207
    assert len(y) == 207
    assert quality["valores_ausentes_total"] == 0
    assert quality["linhas_duplicadas"] == 0


def test_target_is_derived_from_rating_and_has_expected_counts():
    X, y, quality = load_and_validate_dataset(DATA)
    assert int((y == 0).sum()) == 44
    assert int((y == 1).sum()) == 163
    assert quality["divergencias_rotulo_original"] == 31


def test_only_predefined_features_are_used():
    X, y, quality = load_and_validate_dataset(DATA)
    assert list(X.columns) == FEATURES
    assert "Nota_para_o_atendimento_1_a_5" not in X.columns
    assert "Satisfacao" not in X.columns
    assert "Voltaria_a_comprar" not in X.columns
    assert "ID_Resposta" not in X.columns


def test_preprocessor_transforms_all_records_without_missing_values():
    X, y, _ = load_and_validate_dataset(DATA)
    X_with_missing = X.copy()
    X_with_missing.loc[X_with_missing.index[0], "Tempo_de_espera_minutos"] = np.nan
    X_with_missing.loc[X_with_missing.index[1], "Canal_de_atendimento"] = None
    transformed = build_preprocessor().fit_transform(X_with_missing, y)
    assert transformed.shape[0] == len(X)
    assert transformed.shape[1] > len(FEATURES)
    assert np.isfinite(transformed.toarray() if hasattr(transformed, "toarray") else transformed).all()
